<?php
require_once __DIR__.'/includes/functions.php';
unset($_SESSION['portal_user_id']);
redirect('portal-login.php');

