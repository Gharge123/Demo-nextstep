<?php

require_once __DIR__ . '/config/db.php';

$metaTitle = 'Laptop & Device on Rent for Business | Next Step India';
$metaDescription = 'Rent laptops, desktops, MacBooks and workstations for your team. Preconfigured devices, nationwide delivery and support. Get a quote in one day.';

$devices = db()
    ->query(
        "SELECT * FROM devices
         WHERE status = 'active'
         ORDER BY featured DESC, id DESC
         LIMIT 8"
    )
    ->fetchAll();

$testimonials = db()
    ->query(
        "SELECT * FROM testimonials
         WHERE status = 'active'
         ORDER BY id
         LIMIT 3"
    )
    ->fetchAll();

$clients = db()
    ->query(
        "SELECT * FROM clients
         WHERE status = 'active'
         ORDER BY sort_order
         LIMIT 8"
    )
    ->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="container hero-grid">
        <div data-fade>
            <span class="eyebrow">Device-as-a-Service | Pune & Pan India</span>

            <h1>
                Laptops, Desktops and Workstations on Rent — Delivered Configured, Supported Nationwide.
            </h1>

            <p class="lead">
                Next Step equips your teams with business-ready devices on a flexible monthly rental.
                Move IT hardware from CAPEX to OPEX, and let us handle deployment, support and asset tracking across India.
            </p>

            <div class="actions">
                <a class="btn primary" href="<?= url('contact.php') ?>">
                    Request a Rental Quote
                </a>
                <a
                    class="btn outline"
                    href="<?= whatsapp_url() ?>"
                    data-track="whatsapp"
                >
                    Chat on WhatsApp
                </a>
                <a class="text-link" href="<?= url('devices.php') ?>">
                    View Devices
                </a>
                <a class="text-link" href="<?= url('laptop-on-rent-pune.php') ?>">
                    Rent for Personal Use (Pune)
                </a>
            </div>

            <div class="trust-strip">
                <span><?= e(setting('devices_deployed', '5,000+')) ?> devices deployed</span>
                <span><?= e(setting('cities_covered', '50+')) ?> cities covered</span>
                <span>Delivery & pickup included</span>
                <span>Quote within 1 working day</span>
            </div>
        </div>

        <div class="hero-visual" data-fade>
            <img
                class="hero-image"
                src="<?= url('assets/images/work-laptop.jpg') ?>"
                alt="Next Step work laptop rental"
            >

            <div class="hero-visual-overlay">
                <span class="eyebrow" style="color:#fff;">Next Step • Asset Operations</span>
                <h3 style="color:#fff;">Configured. Tagged. Delivered. Supported.</h3>
                <p>
                    Business laptops, performance devices and workstations prepared for your team before dispatch.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">

        <div class="section-head" data-fade>
            <span class="eyebrow">Choose your path</span>

            <h2>Two Ways to Rent With Next Step</h2>
        </div>

        <div class="split-cards">

            <!-- Business Rental -->
            <div class="card rental-path-card" data-fade>

                <span class="icon">🏢</span>

                <h3>
                    For Businesses — Across India
                </h3>

                <p>
                    Equip 5 or 500 employees with preconfigured laptops,
                    desktops, MacBooks and workstations. Nationwide delivery,
                    on-site support, asset dashboard and a dedicated point
                    of contact.
                </p>

                <a
                    class="text-link rental-path-link"
                    href="<?= url('industries.php') ?>"
                >
                    Explore Business Rentals →
                </a>

            </div>


            <!-- Personal Rental -->
            <div class="card rental-path-card" data-fade>

                <span class="icon">🏠</span>

                <h3>
                    For Individuals — In Pune
                </h3>

                <p>
                    Rent a laptop, MacBook, gaming PC, PlayStation 5 or
                    PlayStation 4 on a flexible monthly plan. Free delivery
                    and pickup anywhere in Pune.
                </p>

                <a
                    class="text-link rental-path-link"
                    href="<?= url('laptop-on-rent-pune.php') ?>"
                >
                    Explore Personal Rentals →
                </a>

            </div>

        </div>

    </div>
</section>

<section class="section muted">
    <div class="container">
        <div class="section-head" data-fade>
            <span class="eyebrow">Trusted by growing teams</span>
            <h2>Trusted by Growing Teams Across India</h2>
            <p>
                From early-stage startups to established enterprises, organisations rely on Next Step to keep their people equipped.
            </p>
        </div>

        <div class="logo-grid">
            <?php foreach ($clients as $client): ?>
                <div data-fade><?= e($client['name']) ?></div>
            <?php endforeach; ?>
        </div>

        <div class="stats">
            <div>
                <b><?= e(setting('devices_deployed', '5,000+')) ?></b>
                <span>devices deployed</span>
            </div>
            <div>
                <b><?= e(setting('cities_covered', '50+')) ?></b>
                <span>cities covered</span>
            </div>
            <div>
                <b><?= e(setting('clients_count', '[confirm]')) ?></b>
                <span>business clients</span>
            </div>
            <div>
                <b><?= e(setting('replacement_hours', '[confirm]')) ?></b>
                <span>replacement turnaround</span>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head" data-fade>
            <span class="eyebrow">Brands we support</span>
            <h2>Every Major Brand. One Rental Partner.</h2>
            <p>
                We source, configure and support hardware from the brands your teams already use.
            </p>
        </div>

        <div class="brand-strip">
            <?php foreach (['Dell', 'HP', 'Lenovo', 'Apple', 'ASUS', 'Acer', 'MSI', 'Custom assembled desktops'] as $brand): ?>
                <span data-fade><?= e($brand) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section muted">
    <div class="container">

        <div class="section-head" data-fade>
            <span class="eyebrow">Hardware</span>

            <h2>
                Devices Built Around How Your Team Works
            </h2>

            <p>
                Choose a standard configuration or tell us your workload —
                we will specify the right machine.
            </p>
        </div>


        <div class="device-grid">

            <?php foreach ($devices as $device): ?>

                <article
                    class="device-card"
                    data-fade
                >

                    <!-- Device Image -->
                    <div class="device-image">

                        <img
                            src="<?= e(device_image($device)) ?>"
                            alt="<?= e($device['name']) ?>"
                            loading="lazy"
                        >

                    </div>


                    <!-- Device Details -->
                    <div class="device-content">

                        <span class="tag">
                            <?= e($device['category']) ?>
                        </span>


                        <h3>
                            <?= e($device['name']) ?>
                        </h3>


                        <p class="device-specs">
                            <?= e($device['specs']) ?>
                        </p>


                        <small class="device-use">
                            <strong>Best for:</strong>
                            <?= e($device['use_case']) ?>
                        </small>


                        <?php if ($device['price'] !== null): ?>

                            <strong class="device-price">
                                From ₹<?= e($device['price']) ?>/month
                            </strong>

                        <?php endif; ?>


                        <!-- Enquire Link -->
                        <a
                            class="text-link device-enquire"
                            href="<?= url(
                                'contact.php?device=' .
                                urlencode($device['name'])
                            ) ?>"
                        >
                            Enquire →
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>


        <!-- View All Devices -->
        <div class="center view-all-devices">

            <a
                class="btn outline"
                href="<?= url('devices.php') ?>"
            >
                View All Devices
            </a>

        </div>

    </div>
</section>

<section class="section">
    <div class="container">

        <!-- Section Heading -->
        <div class="section-head" data-fade>

            <span class="eyebrow">
                Why Next Step
            </span>

            <h2>
                Why Companies Choose Next Step
            </h2>

            <p>
                Renting hardware is easy. Keeping a distributed team productive
                is not. That is the part we take ownership of.
            </p>

        </div>


        <!-- Features -->
        <div class="feature-grid">

            <?php

            $features = [

                [
                    'OPEX instead of CAPEX',
                    'Predictable monthly billing, no capital lock-in and no asset disposal problem.'
                ],

                [
                    'Preconfigured deployment',
                    'Devices arrive imaged, MDM-enrolled, software-installed and email-configured.'
                ],

                [
                    'Nationwide logistics',
                    'Delivery and pickup included across India through a local partner network.'
                ],

                [
                    'Local support presence',
                    'On-site engineers in major cities and vendor partners in tier-2 locations.'
                ],

                [
                    'Rapid replacement',
                    'A failed device is replaced rather than repaired on the user’s time, subject to agreed SLA.'
                ],

                [
                    'Complete asset visibility',
                    'A dashboard view of devices, holders, locations, configurations and rental end dates.'
                ],

                [
                    'Scale in both directions',
                    'Add devices for hiring waves and return them when a project closes.'
                ],

                [
                    'One accountable partner',
                    'Dedicated point of contact, helpdesk and WhatsApp support.'
                ],

            ];

            ?>


            <?php foreach ($features as $feature): ?>

                <div
                    class="feature"
                    data-fade
                >

                    <h3>
                        <?= e($feature[0]) ?>
                    </h3>

                    <p>
                        <?= e($feature[1]) ?>
                    </p>

                </div>

            <?php endforeach; ?>

        </div>


        <!-- Additional Content -->
        <div
            class="feature-bottom-content"
            data-fade
        >

            <span class="eyebrow">
                Built for flexible IT operations
            </span>

            <h3>
                Need a rental setup designed around your team?
            </h3>

            <p>
                Tell us your device requirements, team size, locations and
                rental duration. We can recommend the right hardware,
                deployment model and support approach for your business.
            </p>

        </div>


        <!-- Centered CTA Buttons -->
        <div
            class="inline-ctas feature-ctas"
            data-fade
        >

            <a
                href="<?= url('contact.php?source=device-specifications') ?>"
                class="btn outline"
            >
                Request Device Specifications
            </a>


            <a
                href="<?= url('contact.php?source=dashboard-demo') ?>"
                class="btn outline"
            >
                Request a Dashboard Demo
            </a>


            <a
                href="<?= url('about.php#support') ?>"
                class="btn outline"
            >
                See Our Support Model
            </a>

        </div>

    </div>
</section>

<section class="section dark">
    <div class="container two-col">
        <div data-fade>
            <span class="eyebrow">Nationwide logistics</span>
            <h2>Delivered Where Your People Are</h2>
            <p>
                Hiring in Bengaluru, onboarding in Hyderabad or running a support floor in Indore —
                your devices should not depend on where your head office is.
            </p>

            <ul class="light-list">
                <li>Delivery and pickup included</li>
                <li>Insured transit with condition documentation</li>
                <li>Direct-to-employee delivery</li>
                <li>Bulk staged rollouts</li>
                <li>Coordinated collection at end of term</li>
            </ul>

            <a class="btn white" href="<?= url('contact.php') ?>">
                Request a Rental Quote
            </a>
        </div>

        <div class="dashboard-mock" data-fade>
            <div class="mock-header">Asset Dashboard</div>
            <div class="mock-row">
                <span>NS-1024</span>
                <span>Pune</span>
                <span>Active</span>
            </div>
            <div class="mock-row">
                <span>NS-2098</span>
                <span>Bengaluru</span>
                <span>Renewal</span>
            </div>
            <div class="mock-row">
                <span>NS-3102</span>
                <span>Hyderabad</span>
                <span>Transit</span>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head" data-fade>
            <span class="eyebrow">Testimonials</span>
            <h2>What Our Clients Say</h2>
        </div>

        <div class="testimonial-grid">
            <?php foreach ($testimonials as $testimonial): ?>
                <blockquote data-fade>
                    <p>“<?= e($testimonial['quote']) ?>”</p>
                    <footer>
                        <?= e($testimonial['name']) ?> —
                        <?= e($testimonial['designation']) ?>,
                        <?= e($testimonial['company']) ?>,
                        <?= e($testimonial['city']) ?>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section faq">
    <div class="container narrow">
        <div class="section-head"><span class="eyebrow">FAQ</span>
            <h2>Frequently Asked Questions</h2>
        </div>
        <details>
            <summary>What is the minimum rental duration?</summary>
            <p>Business rentals typically start from three months. Individual rentals in Pune start from one month.</p>
        </details>
        <details>
            <summary>Which cities do you serve?</summary>
            <p>Business rentals are served across India, including tier-2 and tier-3 cities. Individual rentals are currently available within Pune and PCMC.</p>
        </details>
        <details>
            <summary>Are delivery and pickup charged separately?</summary>
            <p>No. Delivery and pickup are included in the rental for both business and individual customers.</p>
        </details>
        <details>
            <summary>Can devices be preconfigured with our software and MDM?</summary>
            <p>Yes. OS imaging, software installation, MDM enrolment, email setup and asset tagging are completed before dispatch.</p>
        </details>
        <details>
            <summary>What happens if a device fails?</summary>
            <p>Raise it on the helpdesk or WhatsApp group. We resolve remotely where possible, and dispatch an engineer or replacement device where we cannot.</p>
        </details>
        <details>
            <summary>Can we increase or reduce the number of devices mid-term?</summary>
            <p>Yes. Devices can be added at any point, and returns can be scheduled subject to agreed rental terms.</p>
        </details>
        <details>
            <summary>Do you offer customised or assembled desktops?</summary>
            <p>Yes. Assembled desktops and workstations are built to the specification your workload requires.</p>
        </details>
        <details>
            <summary>What documents are required?</summary>
            <p>Businesses: company registration, GST and a signed rental agreement. Individuals: government-issued ID, address proof and a security deposit.</p>
        </details>
        <details>
            <summary>Is there an option to purchase the device?</summary>
            <p>Buyout options can be discussed at the end of the rental term depending on the device and duration. [confirm policy]</p>
        </details>
        <details>
            <summary>How is billing handled?</summary>
            <p>Monthly invoicing against the agreed rental value, with GST, consolidated across all your devices and locations.</p>
        </details>
    </div>
</section>

<section class="section quote-section" id="request-quote">
    <div class="container">

        <!-- Section Heading -->
        <div class="quote-content" data-fade>

            <span class="eyebrow">
                Request a Quote
            </span>

            <h2>
                Tell Us What You Need
            </h2>

            <p>
                Share your device type, quantity, city and rental duration.
                Our team will recommend the right configuration and provide
                a rental quote within one working day.
            </p>

        </div>


        <!-- Registration / Enquiry Form -->
        <div class="quote-form-area" data-fade>

            <div class="quote-form-header">

                <span class="quote-form-badge">
                    Rental Enquiry
                </span>

                <h3>
                    Get Your Device Rental Quote
                </h3>

                <p>
                    Fill in the details below and our team will contact you
                    with device availability, configuration and pricing.
                </p>

            </div>


            <div class="quote-form-full">

                <?php
                include __DIR__ . '/includes/enquiry_form.php';
                ?>

            </div>


            <!-- Information Before Closing -->
            <div class="quote-form-bottom">

                <div class="quote-benefit">

                    <span class="quote-benefit-icon">
                        ✓
                    </span>

                    <div>
                        <strong>
                            Quick Response
                        </strong>

                        <p>
                            Get a response from our rental team within
                            one working day.
                        </p>
                    </div>

                </div>


                <div class="quote-benefit">

                    <span class="quote-benefit-icon">
                        ✓
                    </span>

                    <div>
                        <strong>
                            Flexible Rental Plans
                        </strong>

                        <p>
                            Choose a rental duration based on your business
                            requirements.
                        </p>
                    </div>

                </div>


                <div class="quote-benefit">

                    <span class="quote-benefit-icon">
                        ✓
                    </span>

                    <div>
                        <strong>
                            Nationwide Support
                        </strong>

                        <p>
                            Delivery, pickup and support available across
                            multiple cities in India.
                        </p>
                    </div>

                </div>

            </div>


            <!-- Contact Options After Form -->
            <div class="quote-after-form">

                <div class="quote-after-content">

                    <span class="eyebrow">
                        Need help?
                    </span>

                    <h3>
                        Prefer to speak with our team directly?
                    </h3>

                    <p>
                        Contact us by phone or WhatsApp for device availability,
                        urgent requirements or help choosing the right
                        configuration.
                    </p>

                </div>


                <div class="quote-after-actions">

                    <a
                        href="<?= track_url('call', 'homepage_quote') ?>"
                        class="btn outline"
                        data-track="call"
                    >
                        Call <?= e(PHONE) ?>
                    </a>


                    <a
                        href="<?= whatsapp_url('Hi Next Step, I need help with a device rental requirement.') ?>"
                        class="btn primary"
                        target="_blank"
                        rel="noopener"
                        data-track="whatsapp"
                    >
                        Chat on WhatsApp
                    </a>

                </div>

            </div>

        </div>

    </div>
</section>

<section class="final-cta">
    <div class="container" data-fade>
        <h2>Ready to Move Your IT Hardware to a Rental Model?</h2>
        <p>
            Delivery & pickup included • Nationwide support • Preconfigured devices • Dedicated account manager
        </p>

        <a class="btn white" href="<?= url('contact.php') ?>">
            Request a Rental Quote
        </a>
        <a
            class="btn outline-white"
            href="<?= whatsapp_url() ?>"
            data-track="whatsapp"
        >
            Chat on WhatsApp
        </a>
        <a
            class="btn outline-white"
            href="<?= track_url('call', 'home') ?>"
            data-track="call"
        >
            Call <?= e(PHONE) ?>
        </a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
