<?php
require_once __DIR__ . '/includes/functions.php';

$metaTitle = 'Helpdesk Status | Next Step';

include __DIR__ . '/includes/header.php';
?>

<div class="container section">
	<span class="eyebrow">Support</span>
	<h1>Helpdesk Status</h1>
	<p>
		Support is coordinated through ticketed workflows, remote support, on-site engineers and replacement
		dispatch where required.
	</p>

	<div class="cards">
		<div class="stat">
			<b>Remote</b>
			<span>OS, drivers, software, network, email and MDM issues</span>
		</div>
		<div class="stat">
			<b>On-site</b>
			<span>Engineer visits in serviced cities</span>
		</div>
		<div class="stat">
			<b>Replacement</b>
			<span>Dispatch when an issue cannot be resolved in place</span>
		</div>
		<div class="stat">
			<b>WhatsApp</b>
			<span>Dedicated client escalation channel</span>
		</div>
	</div>

	<div class="panel">
		<h2>Existing client</h2>
		<p>Log into the client portal to raise and track a ticket.</p>
		<a class="btn" href="<?= url('portal-login.php') ?>">Client Login</a>
	</div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
