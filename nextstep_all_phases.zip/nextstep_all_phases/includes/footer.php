</main>

<footer class="footer">
    <div class="container footer-grid">
        <div>
            <a href="<?= url('index.php') ?>" aria-label="Next Step Home">
                <img
                    class="logo-image footer-logo"
                    src="<?= url('assets/images/nextstep-logo.png') ?>"
                    alt="Next Step"
                >
            </a>
            <p>
                Device-as-a-Service for businesses across India and flexible personal rentals in Pune.
            </p>

            <div class="footer-badges">
                <span>Delivery & pickup included</span>
                <span>Preconfigured before dispatch</span>
                <span>Quote within 1 working day</span>
            </div>
        </div>

        <div>
            <h4>Company</h4>
            <a href="<?= url('about.php') ?>">About Us</a>
            <a href="<?= url('industries.php') ?>">Industries</a>
            <a href="<?= url('resources.php') ?>">Resources</a>
            <a href="<?= url('contact.php') ?>">Contact</a>
            <a href="<?= url('privacy.php') ?>">Privacy</a>
            <a href="<?= url('company-profile.php') ?>">Company Profile</a>
        </div>

        <div>
            <h4>Services</h4>
            <a href="<?= url('devices.php') ?>">Device Catalog</a>
            <a href="<?= url('laptop-on-rent-pune.php') ?>">Pune Rentals</a>
            <a href="<?= url('rental-calculator.php') ?>">Rental Calculator</a>
            <a href="<?= whatsapp_url() ?>" data-track="whatsapp">WhatsApp</a>
        </div>

        <div>
            <h4>Contact</h4>
            <a href="<?= track_url('call', 'footer') ?>" data-track="call">
                📞 <?= e(PHONE) ?>
            </a>
            <a href="<?= whatsapp_url() ?>" data-track="whatsapp">
                💬 WhatsApp
            </a>
            <p>Pimpri-Chinchwad, Maharashtra 411018</p>
            <a
                href="<?= e(setting('google_maps_url', 'https://maps.google.com/')) ?>"
                target="_blank"
                rel="noopener"
            >
                View map
            </a>
        </div>
    </div>

    <div class="container copyright">
        <span>© <?= date('Y') ?> Next Step. All rights reserved.</span>
        <span>GSTIN: <?= e(setting('gstin', '[confirm]')) ?></span>
    </div>
</footer>

<div class="whatsapp">
    <a
        href="<?= whatsapp_url() ?>"
        target="_blank"
        rel="noopener"
        data-track="whatsapp"
    >
        WhatsApp
    </a>
</div>

<div class="mobile-bar">
    <a href="<?= track_url('call', 'mobile') ?>" data-track="call">Call</a>
    <a href="<?= whatsapp_url() ?>" data-track="whatsapp">WhatsApp</a>
    <a href="<?= url('contact.php') ?>">Get Quote</a>
</div>

<div class="modal" id="exitModal">
    <div class="modal-card">
        <button class="modal-close" type="button" aria-label="Close">×</button>
        <span class="eyebrow">Before you go</span>
        <h2>Compare Rental vs Buying</h2>
        <p>
            Download a simple comparison guide for OPEX vs CAPEX hardware decisions.
        </p>
        <a
            class="btn outline"
            href="<?= url('actions/download_comparison.php') ?>"
        >
            Download Comparison Sheet
        </a>
    </div>
</div>

<script>
    window.NEXTSTEP_BASE = <?= json_encode(rtrim(BASE_URL, '/')) ?>;
</script>
<script src="<?= url('assets/js/app.js') ?>"></script>

<?php if (setting('live_chat_enabled', '1') === '1'): ?>
    <button class="chat-launch" id="chatLaunch" type="button">
        Chat Support
    </button>

    <div class="chat-box" id="chatBox">
        <div class="chat-head">
            <span>Next Step Support</span>
            <button id="chatClose" type="button" aria-label="Close chat">×</button>
        </div>

        <div class="chat-body" id="chatBody">
            <p>
                Hi. Ask about pricing, cities, minimum term or device availability.
            </p>
        </div>

        <form id="chatForm">
            <input
                type="hidden"
                name="csrf"
                value="<?= e(csrf_token()) ?>"
            >
            <input
                type="hidden"
                name="action"
                value="send"
            >
            <input
                type="hidden"
                name="session_id"
                value="<?= e($_SESSION['chat_session'] ??= bin2hex(random_bytes(16))) ?>"
            >
            <input
                name="message"
                placeholder="Type your question…"
                autocomplete="off"
                required
            >
            <button type="submit">Send</button>
        </form>
    </div>

    <script>
        (function () {
            const box = document.getElementById('chatBox');
            const launch = document.getElementById('chatLaunch');
            const close = document.getElementById('chatClose');
            const form = document.getElementById('chatForm');
            const body = document.getElementById('chatBody');

            if (!box || !launch || !close || !form || !body) {
                return;
            }

            launch.addEventListener('click', () => {
                box.classList.toggle('show');
            });

            close.addEventListener('click', () => {
                box.classList.remove('show');
            });

            form.addEventListener('submit', async (event) => {
                event.preventDefault();

                const formData = new FormData(form);
                formData.set('action', 'send');

                const message = String(
                    formData.get('message') || ''
                ).trim();

                if (!message) {
                    return;
                }

                try {
                    const response = await fetch(
                        '<?= url('actions/chat.php') ?>',
                        {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                            },
                        }
                    );

                    const result = await response.json();

                    if (!response.ok || !result.ok) {
                        throw new Error(
                            result.message || 'Please try again.'
                        );
                    }

                    body.insertAdjacentHTML(
                        'beforeend',
                        `<p><b>You:</b> ${escapeChat(message)}</p>
                         <p><b>Support:</b> ${escapeChat(result.reply)}
                         <a target="_blank" rel="noopener" href="${result.whatsapp}">
                         Continue on WhatsApp</a></p>`
                    );

                    form.reset();

                    const csrf = form.querySelector('[name="csrf"]');
                    const action = form.querySelector('[name="action"]');
                    const session = form.querySelector('[name="session_id"]');

                    if (csrf) {
                        csrf.value = '<?= e(csrf_token()) ?>';
                    }

                    if (action) {
                        action.value = 'send';
                    }

                    if (session && result.session_id) {
                        session.value = result.session_id;
                    }

                    body.scrollTop = body.scrollHeight;
                } catch (error) {
                    alert(error.message || 'Unable to send message.');
                }
            });

            function escapeChat(value) {
                const element = document.createElement('div');
                element.textContent = value;
                return element.innerHTML;
            }
        })();
    </script>
<?php endif; ?>

</body>
</html>
