<?php

require_once __DIR__ . '/auth.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Admin') ?> | Next Step</title>
    <link
        rel="icon"
        type="image/png"
        href="<?= url('assets/images/nextstep-logo.png') ?>"
    >
    <link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>">
</head>
<body>
<header class="admin-top">
    <a href="<?= url('admin/index.php') ?>">
        <img
            class="admin-brand"
            src="<?= url('assets/images/nextstep-logo.png') ?>"
            alt="Next Step"
        >
    </a>

    <nav>
        <a href="<?= url('admin/index.php') ?>">Dashboard</a>
        <a href="<?= url('admin/leads.php') ?>">Leads</a>
        <a href="<?= url('admin/callbacks.php') ?>">Callbacks</a>
        <a href="<?= url('admin/devices.php') ?>">Devices</a>
        <a href="<?= url('admin/industries.php') ?>">Industries</a>
        <a href="<?= url('admin/blog.php') ?>">Blog</a>
        <a href="<?= url('admin/testimonials.php') ?>">Testimonials</a>
        <a href="<?= url('admin/clients.php') ?>">Clients</a>
        <a href="<?= url('admin/settings.php') ?>">Settings</a>
        <a href="<?= url('admin/phase2_phase3.php') ?>">Phase 2/3</a>
        <a href="<?= url('admin/logout.php') ?>">Logout</a>
    </nav>
</header>

<main class="admin-main">
<?php
$flash = get_flash();
if ($flash):
?>
    <div class="alert <?= e($flash['type']) ?>">
        <?= e($flash['message']) ?>
    </div>
<?php endif; ?>
