<?php

require_once __DIR__ . '/functions.php';

$metaTitle = $metaTitle ?? SITE_NAME . ' | Device-as-a-Service';
$metaDescription = $metaDescription ?? 'Rent laptops, desktops, MacBooks and workstations for business across India. Pune personal rentals available.';
$canonical = $canonical ?? SITE_URL . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$schemaOrg = [
    '@context' => 'https://schema.org',
    '@type' => 'Organization',
    'name' => SITE_NAME,
    'url' => SITE_URL,
    'telephone' => PHONE,
    'address' => [
        '@type' => 'PostalAddress',
        'streetAddress' => 'Naveena Apartments, Telco–Bhosari Road, Trishul Sahakari Housing Society, Yashwantnagar, Pimpri Colony',
        'addressLocality' => 'Pimpri-Chinchwad',
        'addressRegion' => 'Maharashtra',
        'postalCode' => '411018',
        'addressCountry' => 'IN',
    ],
];

$schemaLocal = [
    '@context' => 'https://schema.org',
    '@type' => 'LocalBusiness',
    'name' => SITE_NAME,
    'url' => SITE_URL,
    'telephone' => PHONE,
    'areaServed' => [
        'India',
        'Pune',
        'Pimpri-Chinchwad',
    ],
];

$ga = GA4_ID;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($metaTitle) ?></title>
    <meta name="description" content="<?= e($metaDescription) ?>">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <link rel="icon" type="image/png" href="<?= url('assets/images/nextstep-logo.png') ?>">

    <meta property="og:title" content="<?= e($metaTitle) ?>">
    <meta property="og:description" content="<?= e($metaDescription) ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?= url('assets/images/nextstep-logo.png') ?>">
    <meta name="theme-color" content="#050505">

    <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">

    <script type="application/ld+json">
        <?= json_encode($schemaOrg, JSON_UNESCAPED_SLASHES) ?>
    </script>

    <script type="application/ld+json">
        <?= json_encode($schemaLocal, JSON_UNESCAPED_SLASHES) ?>
    </script>

    <?php if ($ga): ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($ga) ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }

            gtag('js', new Date());
            gtag('config', '<?= e($ga) ?>');
        </script>
    <?php endif; ?>
</head>
<body>
<header class="site-header">
    <div class="container nav">
        <a href="<?= url('index.php') ?>" aria-label="Next Step Home">
            <img
                class="logo-image"
                src="<?= url('assets/images/nextstep-logo.png') ?>"
                alt="Next Step - Let's make things work better"
            >
        </a>

        <button
            class="nav-toggle"
            type="button"
            aria-label="Open navigation"
            onclick="document.querySelector('.nav-links').classList.toggle('open')"
        >
            ☰
        </button>

        <nav class="nav-links">
            <a href="<?= url('index.php') ?>">Home</a>
            <a href="<?= url('industries.php') ?>">Industries</a>
            <a href="<?= url('about.php') ?>">About</a>
            <a href="<?= url('devices.php') ?>">Devices</a>
            <a href="<?= url('resources.php') ?>">Resources</a>
            <a href="<?= url('cities.php') ?>">Cities</a>
            <a href="<?= url('rental-calculator.php') ?>">Calculator</a>
            <a href="<?= url('portal-login.php') ?>">Client Login</a>
            <a href="<?= url('contact.php') ?>">Contact</a>
            <a class="nav-cta" href="<?= url('contact.php') ?>">Get Quote</a>
        </nav>
    </div>
</header>

<main>
