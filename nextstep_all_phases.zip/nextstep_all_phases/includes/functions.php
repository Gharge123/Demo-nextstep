<?php

require_once __DIR__ . '/../config/db.php';

function log_event(string $type, string $source = 'website'): void
{
    try {
        $hash = hash(
            'sha256',
            ($_SERVER['REMOTE_ADDR'] ?? '') . '|nextstep'
        );

        $statement = db()->prepare(
            'INSERT INTO leads_events
            (event_type, source, page_url, ip_hash, user_agent)
            VALUES (?, ?, ?, ?, ?)'
        );

        $statement->execute([
            $type,
            $source,
            substr($_SERVER['HTTP_REFERER'] ?? '', 0, 500),
            $hash,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
        ]);
    } catch (Throwable $exception) {
        error_log('Next Step event log error: ' . $exception->getMessage());
    }
}

function post_webhook(array $payload): void
{
    if (
        !defined('CRM_WEBHOOK_URL') ||
        CRM_WEBHOOK_URL === '' ||
        !function_exists('curl_init')
    ) {
        return;
    }

    try {
        $curl = curl_init(CRM_WEBHOOK_URL);

        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode(
                $payload,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_CONNECTTIMEOUT => 3,
        ]);

        curl_exec($curl);
        curl_close($curl);
    } catch (Throwable $exception) {
        error_log('Next Step webhook error: ' . $exception->getMessage());
    }
}

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    exit;
}

function client_logged_in(): bool
{
    return !empty($_SESSION['portal_user_id']);
}

function require_client(): void
{
    if (!client_logged_in()) {
        redirect('portal-login.php');
    }
}

function client_user(): ?array
{
    if (!client_logged_in()) {
        return null;
    }

    static $user = null;

    if ($user !== null) {
        return $user;
    }

    try {
        $statement = db()->prepare(
            'SELECT * FROM portal_users
             WHERE id = ? AND status = "active"
             LIMIT 1'
        );

        $statement->execute([
            (int) $_SESSION['portal_user_id'],
        ]);

        $user = $statement->fetch() ?: null;

        if ($user === null) {
            unset($_SESSION['portal_user_id']);
        }

        return $user;
    } catch (Throwable $exception) {
        error_log('Next Step client user error: ' . $exception->getMessage());
        return null;
    }
}

function client_asset(int $id): ?array
{
    if (!client_logged_in()) {
        return null;
    }

    $statement = db()->prepare(
        'SELECT a.* FROM assets a
         WHERE a.id = ? AND a.portal_user_id = ?
         LIMIT 1'
    );

    $statement->execute([
        $id,
        (int) ($_SESSION['portal_user_id'] ?? 0),
    ]);

    return $statement->fetch() ?: null;
}

function clean_slug(string $value): string
{
    $value = strtolower(trim($value));
    $value = str_replace(' ', '-', $value);
    $value = preg_replace('/[^a-z0-9-]+/', '-', $value) ?? '';
    $value = preg_replace('/-+/', '-', $value) ?? '';

    return trim($value, '-');
}

function device_image(array $device): string
{
    $stored = trim((string) ($device['image'] ?? ''));

    if ($stored !== '') {
        if (
            str_starts_with($stored, 'http://') ||
            str_starts_with($stored, 'https://') ||
            str_starts_with($stored, '/')
        ) {
            return $stored;
        }

        return url(ltrim($stored, '/'));
    }

    $category = strtolower((string) ($device['category'] ?? ''));
    $name = strtolower((string) ($device['name'] ?? ''));

    if (str_contains($category, 'gaming pc')) {
        $file = 'gaming-pc.jpg';
    } elseif (str_contains($category, 'gaming')) {
        $file = 'gaming-laptop.jpg';
    } elseif (str_contains($category, 'console')) {
        $file = 'console.jpg';
    } elseif (str_contains($category, 'macbook') || str_contains($name, 'macbook')) {
        $file = 'macbook.jpg';
    } elseif (str_contains($category, 'workstation')) {
        $file = 'workstation.jpg';
    } elseif (str_contains($category, 'assembled')) {
        $file = 'assembled-desktop.jpg';
    } elseif (str_contains($category, 'desktop')) {
        $file = 'desktop.jpg';
    } elseif (str_contains($name, 'performance')) {
        $file = 'gaming-laptop.jpg';
    } else {
        $file = 'work-laptop.jpg';
    }

    return url('assets/images/devices/' . $file);
}

function valid_email(string $email): bool
{
    return filter_var(
        trim($email),
        FILTER_VALIDATE_EMAIL
    ) !== false;
}

function whatsapp_message(string $message): string
{
    return whatsapp_url($message);
}
