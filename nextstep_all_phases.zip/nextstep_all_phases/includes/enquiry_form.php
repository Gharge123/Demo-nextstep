<?php
$selectedDevice = $_GET['device'] ?? '';
?>

<form
	method="post"
	action="<?= url('actions/submit_enquiry.php') ?>"
	class="enquiry-form"
	onsubmit="return validateEnquiry(this)"
>
	<input type="hidden" name="csrf" value="<?= csrf_token() ?>">
	<input type="hidden" name="source" value="<?= e($_GET['source'] ?? 'website') ?>">
	<input class="honeypot" name="website" tabindex="-1" autocomplete="off">

	<div class="toggle">
		<label>
			<input type="radio" name="segment" value="business" checked>
			Business
		</label>
		<label>
			<input type="radio" name="segment" value="individual">
			Individual (Pune)
		</label>
	</div>

	<div class="form-grid">
		<label>
			Full name*
			<input name="name" required>
		</label>

		<label id="companyField">
			Company name
			<input name="company">
		</label>

		<label>
			Email address*
			<input type="email" name="email" required>
		</label>

		<label>
			Phone / WhatsApp*
			<input
				name="phone"
				inputmode="numeric"
				pattern="[0-9]{10}"
				maxlength="10"
				required
			>
		</label>

		<label>
			City / delivery location*
			<input name="city" list="cities" required>
			<datalist id="cities">
				<option>Delhi NCR</option>
				<option>Mumbai</option>
				<option>Bengaluru</option>
				<option>Hyderabad</option>
				<option>Chennai</option>
				<option>Pune</option>
				<option>Pimpri-Chinchwad</option>
				<option>Indore</option>
			</datalist>
		</label>

		<label>
			Rental duration*
			<select name="duration" required>
				<option value="">Select duration</option>
				<option>1–3 months</option>
				<option>3–6 months</option>
				<option>6–12 months</option>
				<option>12+ months</option>
			</select>
		</label>
	</div>

	<fieldset>
		<legend>Device type*</legend>
		<div class="checks">
			<?php foreach (['Laptop', 'Desktop', 'Assembled Desktop', 'MacBook', 'Workstation', 'Gaming PC', 'PS5 / PS4'] as $device): ?>
				<label>
					<input
						type="checkbox"
						name="devices[]"
						value="<?= e($device) ?>"
						<?= $selectedDevice === $device ? 'checked' : '' ?>
					>
					<?= e($device) ?>
				</label>
			<?php endforeach; ?>
		</div>
	</fieldset>

	<label>
		Number of devices*
		<input type="number" name="quantity" min="1" max="5000" value="1" required>
	</label>

	<label>
		Configuration / software requirements
		<textarea name="requirements" rows="4" placeholder="MDM, RAM, SSD, design software, GPU, VPN, etc."></textarea>
	</label>

	<label>
		Message
		<textarea name="message" rows="3"></textarea>
	</label>

	<label>
		Preferred start date
		<input type="date" name="start_date">
	</label>
<br>
	<button class="btn primary" type="submit">Send My Requirement</button>

	<p class="privacy">
		Your details are never shared with third parties. We use them only to respond to this enquiry.
	</p>
</form>