<?php

require_once __DIR__ . '/config/db.php';

$metaTitle = 'Devices on Rent | Laptops, MacBooks, Desktops & Workstations | Next Step';
$metaDescription = 'Browse laptops, desktops, MacBooks, workstations, gaming PCs and consoles with specifications and enquiry actions.';

$category = trim($_GET['category'] ?? '');
$brand = trim($_GET['brand'] ?? '');
$use = trim($_GET['use'] ?? '');

$where = [
    "status = 'active'",
];
$params = [];

if ($category !== '') {
    $where[] = 'category = :category';
    $params[':category'] = $category;
}

if ($brand !== '') {
    $where[] = 'brand LIKE :brand';
    $params[':brand'] = '%' . $brand . '%';
}

if ($use !== '') {
    $where[] = 'use_case LIKE :use_case';
    $params[':use_case'] = '%' . $use . '%';
}

$sql = sprintf(
    'SELECT * FROM devices WHERE %s ORDER BY featured DESC, id DESC',
    implode(' AND ', $where)
);

$statement = db()->prepare($sql);
$statement->execute($params);
$devices = $statement->fetchAll();

$categories = db()
    ->query(
        "SELECT DISTINCT category
         FROM devices
         WHERE status = 'active'
         ORDER BY category"
    )
    ->fetchAll(PDO::FETCH_COLUMN);

$brands = db()
    ->query(
        "SELECT DISTINCT brand
         FROM devices
         WHERE status = 'active'
           AND brand <> ''
         ORDER BY brand"
    )
    ->fetchAll(PDO::FETCH_COLUMN);

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Device Catalog</span>
        <h1>Devices Built Around How Your Team Works</h1>
        <p>
            Filter by type and brand, review specifications and enquire for availability.
            Every device is supplied with required accessories; monitors, docks, headsets
            and webcams can be added on request.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form class="filter-form" method="get">
            <select name="category">
                <option value="">All device types</option>
                <?php foreach ($categories as $item): ?>
                    <option
                        value="<?= e($item) ?>"
                        <?= $category === $item ? 'selected' : '' ?>
                    >
                        <?= e($item) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="brand">
                <option value="">All brands</option>
                <?php foreach ($brands as $item): ?>
                    <option
                        value="<?= e($item) ?>"
                        <?= $brand === $item ? 'selected' : '' ?>
                    >
                        <?= e($item) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <input
                name="use"
                value="<?= e($use) ?>"
                placeholder="Use case e.g. CAD, gaming, BPO"
            >

            <button class="btn primary" type="submit">Filter</button>
            <a class="btn outline" href="<?= url('devices.php') ?>">Reset</a>
        </form>

        <?php if (!$devices): ?>
            <div class="panel">
                <h2>No matching devices</h2>
                <p>
                    Try another category, brand or use case, or contact us for a custom configuration.
                </p>
            </div>
        <?php endif; ?>

        <div class="device-grid">
            <?php foreach ($devices as $device): ?>
                <article class="device-card" data-fade>
                    <div class="device-image">
                        <img
                            src="<?= e(device_image($device)) ?>"
                            alt="<?= e($device['name']) ?>"
                            loading="lazy"
                        >
                    </div>

                    <div>
                        <span class="tag">
                            <?= e($device['category']) ?>
                        </span>

                        <h2><?= e($device['name']) ?></h2>

                        <p>
                            <b>Brand:</b>
                            <?= e($device['brand']) ?>
                        </p>

                        <p><?= nl2br(e($device['specs'])) ?></p>

                        <p>
                            <b>Best suited for:</b>
                            <?= e($device['use_case']) ?>
                        </p>

                        <p>
                            <b>Accessories:</b>
                            <?= e($device['accessories']) ?>
                        </p>

                        <?php if ($device['price'] !== null): ?>
                            <strong>
                                ₹<?= e($device['price']) ?>/month
                            </strong>
                        <?php endif; ?>

                        <a
                            class="btn small primary"
                            href="<?= url('contact.php?device=' . urlencode($device['name'])) ?>"
                        
                        >
                            Enquire
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
