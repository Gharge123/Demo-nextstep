<?php
require_once __DIR__ . '/config/db.php';

$metaTitle = 'Laptop, MacBook & PS5 on Rent in Pune | Next Step';
$metaDescription = 'Rent laptops, MacBooks, gaming PCs and PlayStation consoles in Pune. Flexible monthly plans, free delivery and pickup, upgrade anytime.';

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
	<div class="container">
		<span class="eyebrow">Pune Rentals</span>
		<h1>Laptop, MacBook & PS5 on Rent in Pune</h1>
		<p>
			Rent laptops, MacBooks, gaming PCs and PlayStation consoles in Pune and PCMC. Flexible monthly plans,
			free delivery and pickup, and responsive support.
		</p>
		<div class="actions">
			<a
				class="btn white"
				href="<?= whatsapp_url('Hi Next Step, I would like to check Pune rental availability.') ?>"
				data-track="whatsapp"
			>
				WhatsApp Us for Availability
			</a>
			<a class="btn white" href="<?= url('contact.php?segment=individual') ?>">Send Enquiry</a>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="split-cards">
			<div class="card">
				<h2>Laptops</h2>
				<p>Students, professionals, work-from-home and short assignments.</p>
			</div>
			<div class="card">
				<h2>MacBooks</h2>
				<p>Designers, editors, developers and content creators.</p>
			</div>
			<div class="card">
				<h2>Gaming PCs</h2>
				<p>Gamers, streamers and creators needing high-end graphics.</p>
			</div>
			<div class="card">
				<h2>PlayStation 5 & 4</h2>
				<p>Weekend rentals, holidays, house parties and long-term gaming.</p>
			</div>
		</div>

		<div class="section-head local-copy">
			<h2>Simple Monthly Rental Model</h2>
			<ul>
				<li>Flexible plans — rent monthly, extend or close subject to agreed terms</li>
				<li>Upgrade anytime to a higher configuration, subject to availability</li>
				<li>Free delivery, installation and pickup across Pune and PCMC</li>
				<li>End-to-end support — if something fails, replacement is handled according to rental terms</li>
				<li>Tested, sanitised devices with required accessories</li>
			</ul>
		</div>

		<div class="two-col">
			<div>
				<h2>Documents</h2>
				<p>
					Individuals: government-issued ID, address proof and a security deposit. Final KYC requirements
					are confirmed before dispatch.
				</p>
			</div>
			<div>
				<h2>Coverage</h2>
				<p>Pune city limits and PCMC. Business rentals are available across India.</p>
			</div>
		</div>
	</div>
</section>

<section class="section muted">
	<div class="container">
		<div class="section-head">
			<span class="eyebrow">Available Devices</span>
			<h2>Check Current Availability</h2>
		</div>

		<div class="device-grid">
			<?php
			$devices = db()
				->query("SELECT * FROM devices WHERE status='active' AND category IN ('Laptop','MacBook','Gaming PC','Console') ORDER BY featured DESC,id")
				->fetchAll();
			foreach ($devices as $device):
			?>
				<article class="device-card">
					<div class="device-image">
						<div class="placeholder">💻</div>
					</div>
					<div>
						<span class="tag"><?= e($device['category']) ?></span>
						<h3><?= e($device['name']) ?></h3>
						<p><?= e($device['specs']) ?></p>
						<a
							href="<?= whatsapp_url('Hi Next Step, I want availability for ' . $device['name'] . ' in Pune.') ?>"
							data-track="whatsapp"
						>
							Check Availability →
						</a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
