<?php
require_once __DIR__ . '/config/db.php';

$slug = trim($_GET['slug'] ?? '');
$statement = db()->prepare("SELECT * FROM posts WHERE slug=? AND status='published' LIMIT 1");
$statement->execute([$slug]);
$post = $statement->fetch();

if (!$post) {
    http_response_code(404);
    exit('Article not found');
}

$metaTitle = $post['meta_title'] ?: $post['title'] . ' | Next Step';
$metaDescription = $post['meta_description'] ?: $post['excerpt'];
$canonical = SITE_URL . '/post.php?slug=' . rawurlencode($post['slug']);

include __DIR__ . '/includes/header.php';
?>

<article class="section">
    <div class="container article">
        <span class="tag"><?= e($post['category']) ?></span>
        <h1><?= e($post['title']) ?></h1>

        <div class="article-meta">
            <?= e($post['read_time']) ?> ·
            <?= e(date('d M Y', strtotime($post['published_at']))) ?>
        </div>

        <p class="lead"><?= e($post['excerpt']) ?></p>

        <div class="article-content"><?= $post['content'] ?></div>

        <div class="final-mini">
            <h3>Need help choosing devices?</h3>
            <a class="btn primary" href="<?= url('contact.php?source=blog') ?>">
                Request a Rental Quote
            </a>
            <a class="btn outline" href="<?= whatsapp_url() ?>" data-track="whatsapp">
                Chat on WhatsApp
            </a>
        </div>
    </div>
</article>

<?php include __DIR__ . '/includes/footer.php'; ?>
