<?php
require_once __DIR__ . '/config/db.php';

header('Content-Type: application/xml; charset=utf-8');

$urls = [
	SITE_URL . '/',
	SITE_URL . '/industries.php',
	SITE_URL . '/about.php',
	SITE_URL . '/contact.php',
	SITE_URL . '/resources.php',
	SITE_URL . '/devices.php',
	SITE_URL . '/laptop-on-rent-pune.php',
	SITE_URL . '/privacy.php',
	SITE_URL . '/cities.php',
	SITE_URL . '/rental-calculator.php',
	SITE_URL . '/company-profile.php',
	SITE_URL . '/helpdesk-status.php',
];

foreach (db()->query("SELECT slug FROM posts WHERE status='published'") as $post) {
	$urls[] = SITE_URL . '/post.php?slug=' . rawurlencode($post['slug']);
}

foreach (db()->query("SELECT slug FROM cities WHERE status='active'") as $city) {
	$urls[] = SITE_URL . '/city.php?slug=' . rawurlencode($city['slug']);
}

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
	<?php foreach ($urls as $url): ?>
		<url>
			<loc><?= e($url) ?></loc>
			<changefreq>weekly</changefreq>
			<priority><?= str_ends_with($url, '/') ? '1.0' : '0.8' ?></priority>
		</url>
	<?php endforeach; ?>
</urlset>