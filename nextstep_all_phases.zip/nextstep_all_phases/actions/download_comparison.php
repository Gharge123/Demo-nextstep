<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: text/html; charset=UTF-8');
header('Content-Disposition: attachment; filename="next-step-rental-comparison.html"');
?>

<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Next Step Rental Comparison</title>
	<style>
		body {
			font-family: Arial;
			padding: 40px;
			color: #142033;
		}

		table {
			border-collapse: collapse;
			width: 100%;
		}

		td,
		th {
			border: 1px solid #ccc;
			padding: 12px;
			text-align: left;
		}

		h1 {
			color: #071a33;
		}
	</style>
</head>
<body>
	<h1>Next Step — Rental Model Comparison</h1>
	<p>
		This guide helps teams compare owned hardware with a managed Device-as-a-Service model.
	</p>

	<table>
		<tr>
			<th>Area</th>
			<th>Buying / CAPEX</th>
			<th>Rental / OPEX</th>
		</tr>
		<tr>
			<td>Upfront capital</td>
			<td>Large purchase</td>
			<td>Predictable monthly rental</td>
		</tr>
		<tr>
			<td>Configuration</td>
			<td>Internal IT workload</td>
			<td>Preconfigured before dispatch</td>
		</tr>
		<tr>
			<td>Support</td>
			<td>Multiple vendors / service centres</td>
			<td>Managed support and escalation</td>
		</tr>
		<tr>
			<td>Scaling</td>
			<td>Purchase and later disposal</td>
			<td>Add or return devices subject to terms</td>
		</tr>
		<tr>
			<td>Asset visibility</td>
			<td>Internal records</td>
			<td>Dashboard visibility</td>
		</tr>
		<tr>
			<td>Recovery</td>
			<td>Internal exit process</td>
			<td>Coordinated collection and reconciliation</td>
		</tr>
	</table>

	<p>Next Step: +91 79720 37331 | <?= e(SITE_URL) ?></p>
</body>
</html>
