<?php
require_once __DIR__ . '/../includes/functions.php';

verify_csrf();

if (!empty($_POST['website'])) {
    redirect('contact.php');
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = preg_replace('/\D+/', '', $_POST['phone'] ?? '');
$segment = $_POST['segment'] ?? 'business';
$company = trim($_POST['company'] ?? '');
$city = trim($_POST['city'] ?? '');
$duration = trim($_POST['duration'] ?? '');
$quantity = (int) ($_POST['quantity'] ?? 0);
$requirements = trim($_POST['requirements'] ?? '');
$message = trim($_POST['message'] ?? '');
$start = $_POST['start_date'] ?? null;
$source = trim($_POST['source'] ?? 'website');
$devices = $_POST['devices'] ?? [];

if (!in_array($segment, ['business', 'individual'], true)) {
    $segment = 'business';
}

if ($segment === 'individual' && $city === '') {
    $city = 'Pune';
}

if (
    !$name
    || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || !preg_match('/^[0-9]{10}$/', $phone)
    || !$city
    || !$duration
    || $quantity < 1
    || !is_array($devices)
    || !count($devices)
) {
    flash('error', 'Please complete all required fields correctly.');
    redirect('contact.php');
}

$allowed = [
    'Laptop',
    'Desktop',
    'Assembled Desktop',
    'MacBook',
    'Workstation',
    'Gaming PC',
    'PS5 / PS4',
];
$devices = array_values(array_intersect($devices, $allowed));

if (!$devices) {
    flash('error', 'Please select at least one device type.');
    redirect('contact.php');
}

$statement = db()->prepare(
    'INSERT INTO enquiries(segment,name,company,email,phone,city,devices,quantity,duration,requirements,message,start_date,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)'
);
$statement->execute([
    $segment,
    $name,
    $company,
    $email,
    $phone,
    $city,
    implode(', ', $devices),
    $quantity,
    $duration,
    $requirements,
    $message,
    $start ?: null,
    $source,
]);

$id = (int) db()->lastInsertId();
$body = "New Next Step rental enquiry #$id\n\n"
    . "Name: $name\n"
    . "Segment: $segment\n"
    . "Company: $company\n"
    . "Email: $email\n"
    . "Phone: $phone\n"
    . "City: $city\n"
    . 'Devices: ' . implode(', ', $devices) . "\n"
    . "Quantity: $quantity\n"
    . "Duration: $duration\n"
    . 'Start date: ' . ($start ?: 'Not provided') . "\n"
    . "Requirements: $requirements\n"
    . "Message: $message\n"
    . "Source: $source";

notify_email(
    setting('sales_email', SALES_EMAIL),
    'New Next Step Rental Enquiry #' . $id,
    $body
);
notify_email(
    $email,
    'Next Step — Enquiry Received',
    'Thank you, ' . $name . '. Your requirement has reached our team. You will hear from us within one working day. For anything urgent, message us on WhatsApp at +91 79720 37331.'
);
post_webhook([
    'type' => 'rental_enquiry',
    'id' => $id,
    'name' => $name,
    'segment' => $segment,
    'company' => $company,
    'email' => $email,
    'phone' => $phone,
    'city' => $city,
    'devices' => $devices,
    'quantity' => $quantity,
    'duration' => $duration,
    'requirements' => $requirements,
    'source' => $source,
]);

log_event('form_submit', $source);
flash(
    'success',
    'Thank you — your requirement has reached our team. You will hear from us within one working day. For anything urgent, message us on WhatsApp at +91 79720 37331.'
);
redirect('contact.php');

