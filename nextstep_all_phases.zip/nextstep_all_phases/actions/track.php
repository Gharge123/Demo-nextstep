<?php
require_once __DIR__.'/../includes/functions.php';
$type=$_GET['type']??'click';
$source=$_GET['source']??'website';
log_event($type,$source);
if($type==='call') {
    header('Location: tel:+917972037331');
    exit;
    
}
if($type==='whatsapp') {
    header('Location: '.whatsapp_url());
    exit;
    
}
header('Location: '.url('contact.php'));
exit;

