<?php
require_once __DIR__ . '/../includes/functions.php';

verify_csrf();

if (!empty($_POST['website'])) {
    redirect('contact.php');
}

$name = trim($_POST['name'] ?? '');
$phone = preg_replace('/\D+/', '', $_POST['phone'] ?? '');
$time = trim($_POST['preferred_time'] ?? '');

if (!$name || !preg_match('/^[0-9]{10}$/', $phone) || !$time) {
    flash('error', 'Please enter a valid name, 10-digit phone and preferred time.');
    redirect('contact.php');
}

$statement = db()->prepare('INSERT INTO callbacks(name,phone,preferred_time) VALUES(?,?,?)');
$statement->execute([$name, $phone, $time]);
$id = db()->lastInsertId();

notify_email(
    setting('sales_email', SALES_EMAIL),
    'New Callback Request #' . $id,
    "Name: $name\nPhone: $phone\nPreferred time: $time"
);

log_event('callback', 'contact');
flash('success', 'Callback request received. Our team will contact you during your preferred time.');
redirect('contact.php');

