<?php
require_once __DIR__ . '/../includes/functions.php';

verify_csrf();

$email = trim($_POST['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    flash('error', 'Please enter a valid email address.');
    redirect('resources.php');
}

$statement = db()->prepare(
    'INSERT INTO newsletters(email) VALUES(?) ON DUPLICATE KEY UPDATE email=email'
);
$statement->execute([$email]);

notify_email(setting('sales_email', SALES_EMAIL), 'New Resources Subscriber', $email);
log_event('newsletter', 'resources');
flash('success', 'You are subscribed for updates.');
redirect('resources.php');

