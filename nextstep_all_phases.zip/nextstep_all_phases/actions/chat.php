<?php

require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response([
        'ok' => false,
        'message' => 'Only POST requests are allowed.',
    ], 405);
}

$action = trim($_POST['action'] ?? '');
$message = trim($_POST['message'] ?? '');
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$sessionId = trim($_POST['session_id'] ?? '');

/* Keep compatibility with older frontend code that omitted action=send. */
if ($action === '' && $message !== '') {
    $action = 'send';
}

if ($action !== 'send') {
    json_response([
        'ok' => false,
        'message' => 'Invalid chat action.',
    ], 400);
}

verify_csrf();

if ($message === '') {
    json_response([
        'ok' => false,
        'message' => 'Please enter a message.',
    ], 422);
}

if (mb_strlen($message) > 5000) {
    json_response([
        'ok' => false,
        'message' => 'Message cannot be longer than 5000 characters.',
    ], 422);
}

if (
    $email !== '' &&
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {
    json_response([
        'ok' => false,
        'message' => 'Please enter a valid email address.',
    ], 422);
}

if ($sessionId === '') {
    $sessionId = bin2hex(random_bytes(16));
}

$sessionId = substr($sessionId, 0, 100);

$reply = 'Thanks for contacting Next Step. For pricing, cities served or device availability, you can continue on WhatsApp and our team can assist you.';

try {
    $statement = db()->prepare(
        'INSERT INTO chat_messages
        (session_id, visitor_name, visitor_email, message, reply)
        VALUES (?, ?, ?, ?, ?)'
    );

    $statement->execute([
        $sessionId,
        $name,
        $email,
        $message,
        $reply,
    ]);

    log_event('live_chat', 'website');

    json_response([
        'ok' => true,
        'message' => 'Message sent successfully.',
        'reply' => $reply,
        'session_id' => $sessionId,
        'whatsapp' => whatsapp_url(
            'Hi Next Step, I started a website chat and need help with: ' . $message
        ),
    ]);
} catch (PDOException $exception) {
    error_log('Next Step chat database error: ' . $exception->getMessage());

    json_response([
        'ok' => false,
        'message' => 'Unable to save your message. Please try again or use WhatsApp.',
    ], 500);
} catch (Throwable $exception) {
    error_log('Next Step chat error: ' . $exception->getMessage());

    json_response([
        'ok' => false,
        'message' => 'Unable to send your message. Please try again.',
    ], 500);
}
