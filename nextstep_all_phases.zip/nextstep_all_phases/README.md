# Next Step — Core PHP + MySQL — All Phases

This is the complete `nextstep_all_phases` Core PHP + MySQL project package.

## Project path for XAMPP

Copy the complete folder to:

```text
C:\xampp\htdocs\nextstep_all_phases\
```

Open:

```text
http://localhost/nextstep_all_phases/
```

The project `BASE_URL` is already configured as:

```php
define('BASE_URL', '/nextstep_all_phases');
```

The current code uses PHP constants, so the actual project file contains `const BASE_URL = '/nextstep_all_phases';`.

## Theme update

The website has been redesigned in a premium black-and-white style to match the supplied Next Step logo.

Included:

- Supplied Next Step logo in header, footer, admin and favicon.
- Black buttons with white text.
- White/off-white page backgrounds.
- Black hero and CTA sections.
- Card shadows and hover lift effects.
- Fade-in scroll animations.
- Responsive mobile navigation.
- Responsive device cards and forms.
- Mobile bottom contact bar.

## Device imagery

Local device assets are stored under:

```text
assets/images/devices/
```

Included device images:

```text
work-laptop.jpg
gaming-laptop.jpg
desktop.jpg
assembled-desktop.jpg
macbook.jpg
workstation.jpg
gaming-pc.jpg
console.jpg
```

The first three primary photographs were supplied in the project conversation and are used as the main imagery. Additional device-specific local variants are included so the ZIP remains self-contained and does not depend on external image hosting.

## Database

Import:

```text
database.sql
```

If the `nextstep` database already exists and you do not want to re-import the complete schema, run:

```text
database_theme_update.sql
```

This updates the device image paths only.

## Important fixes included

### Device catalog PDO error

The previous filter query reused named placeholders multiple times, which can cause `SQLSTATE[HY093] Invalid parameter number` when PDO native prepares are enabled. The new `devices.php` builds the WHERE clause dynamically and uses each parameter once.

### Resources PDO error

The resources filter now uses one named parameter only when a category is supplied. The unfiltered query uses a separate SQL statement.

### Live chat 400 / Invalid chat action

The chat form now submits:

```text
action=send
```

The backend also remains compatible with older clients that send a message without the action field.

### Duplicate `e()` error

`e()` is defined only in `config/config.php`. `includes/functions.php` does not redeclare it.

## Main scope

### Phase 1

- Home
- Industries
- About
- Contact
- Resources / Blog
- Device catalog
- Device filtering
- Business rental enquiry
- Individual Pune rental enquiry
- CSRF protection
- Honeypot protection
- Email notification hooks
- Optional CRM webhook
- WhatsApp tracking
- Click-to-call tracking
- Responsive UI
- Blog CMS
- SEO metadata
- Canonical URLs
- Schema markup
- FAQ
- Testimonials
- Client logos

### Phase 2

- Client portal login
- Client asset dashboard
- Asset records
- Helpdesk ticket workflow
- Helpdesk status page
- Website live chat
- WhatsApp handoff
- Company profile download
- Admin portal and asset management
- Admin ticket management
- Admin chat management

### Phase 3

- Rental calculator
- Calculator pricing management
- Calculator lead capture
- City landing pages
- City index
- XML sitemap integration

## Admin

```text
http://localhost/nextstep_all_phases/admin/login.php
```

Use the supplied database credentials for development and change all demo credentials before production.

## Final production checks

Before publishing the website:

1. Replace all `[confirm]` values in Admin > Settings.
2. Replace demo portal credentials.
3. Configure SMTP/mail delivery instead of relying on PHP `mail()`.
4. Set production `SITE_URL`.
5. Configure WhatsApp, phone and email values.
6. Enable HTTPS.
7. Review all client, testimonial and SLA claims.
8. Replace any placeholder pricing or calculator values with approved commercial pricing.
