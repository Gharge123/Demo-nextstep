<?php
require_once __DIR__ . '/includes/functions.php';

$slug = clean_slug($_GET['slug'] ?? '');
$statement = db()->prepare('SELECT * FROM cities WHERE slug=? AND status="active" LIMIT 1');
$statement->execute([$slug]);
$city = $statement->fetch();

if (!$city) {
    http_response_code(404);
    $metaTitle = 'City Not Found | Next Step';

    include __DIR__ . '/includes/header.php';
    ?>
    <div class="container section">
        <h1>City page not found</h1>
        <a class="btn" href="<?= url('index.php') ?>">Back Home</a>
    </div>
    <?php
    include __DIR__ . '/includes/footer.php';
    exit;
}

$metaTitle = $city['meta_title'] ?: $city['headline'] . ' | Next Step';
$metaDescription = $city['meta_description'];
$canonical = SITE_URL . '/city.php?slug=' . rawurlencode($city['slug']);

include __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <span class="eyebrow">Device-as-a-Service | <?= e($city['region']) ?></span>
    <h1><?= e($city['headline']) ?></h1>
    <p class="lead"><?= e($city['intro']) ?></p>

    <div class="hero-actions">
        <a class="btn" href="<?= url('contact.php') ?>">Request a Rental Quote</a>
        <a
            class="btn outline"
            href="<?= whatsapp_url('Hi Next Step, I need device rental in ' . $city['name']) ?>"
            target="_blank"
        >
            WhatsApp
        </a>
    </div>

    <div class="cards">
        <div class="stat">
            <b>Coverage</b>
            <span><?= e($city['coverage']) ?></span>
        </div>
        <div class="stat">
            <b>Devices</b>
            <span><?= e($city['devices']) ?></span>
        </div>
        <div class="stat">
            <b>Support</b>
            <span><?= e($city['support']) ?></span>
        </div>
    </div>

    <div class="panel">
        <h2>Why use a rental model?</h2>
        <p>
            Move hardware from CAPEX to predictable OPEX, receive configured devices before dispatch, and scale
            the number of devices with project and headcount changes.
        </p>
        <a href="<?= url('rental-calculator.php') ?>">Estimate rental cost</a>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
