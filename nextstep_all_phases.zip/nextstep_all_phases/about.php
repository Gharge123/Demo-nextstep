<?php
require_once __DIR__ . '/config/db.php';

$metaTitle = 'About Next Step | Device-as-a-Service Company in India';
$metaDescription = 'Next Step provides laptops, desktops and workstations on rent across India, with preconfigured deployment, asset tracking and managed support.';

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">About Us</span>
        <h1>We Keep India's Teams Equipped and Working</h1>
        <p>
            Next Step is a Device-as-a-Service company built on a simple belief — organisations should be able
            to access the hardware they need without buying, maintaining or writing it off.
        </p>
        <a class="btn white" href="<?= url('contact.php') ?>">Talk to Our Team</a>
    </div>
</section>

<section class="section">
    <div class="container prose">
        <h2>Our Story</h2>
        <p>
            Next Step began in Pune with a straightforward observation: growing companies were spending
            disproportionate time and capital on device procurement. Machines were ordered late, configured
            inconsistently, supported poorly and disposed of at a loss. Meanwhile, individuals needed good
            hardware for short periods and had no reasonable option other than buying it. We built one operation
            to solve both problems — a rental model backed by disciplined configuration, structured support and
            honest logistics.
        </p>
        <p>
            What started as local laptop and console rentals in Pune now serves organisations across India, from
            startups renting their first ten machines to enterprises running multi-city deployments.
            <?= e(setting('founding_year', '[confirm founding year and milestones]')) ?>
        </p>

        <h2>What We Do</h2>
        <p>
            We provide laptops, desktops, assembled desktops, MacBooks and workstations on rent to businesses
            across India, and laptops, MacBooks, gaming PCs and PlayStation consoles to individuals in Pune.
            Around that hardware we deliver configuration, deployment, support, asset tracking and end-of-term
            recovery.
        </p>

        <h2>Our Service Philosophy</h2>
        <ul>
            <li><b>Reliability is an operation, not a promise.</b> Every commitment is backed by a defined process.</li>
            <li><b>Configuration before dispatch.</b> We finish the work before the device leaves us.</li>
            <li><b>One accountable contact.</b> A named account manager owns the relationship end to end.</li>
            <li><b>Transparent commercials.</b> Clear monthly rentals, inclusions and terms.</li>
            <li><b>Respect for the user's time.</b> Get them working quickly and keep them working.</li>
        </ul>
    </div>
</section>

<section class="section muted">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Operational Coverage</span>
            <h2>Built for India. Managed from Pune.</h2>
        </div>

        <div class="stats">
            <div>
                <b>Headquarters</b>
                <span>Pune, Maharashtra — Pimpri-Chinchwad</span>
            </div>
            <div>
                <b>Business rentals</b>
                <span>Pan-India delivery, deployment, support and pickup</span>
            </div>
            <div>
                <b>Individual rentals</b>
                <span>Pune city and PCMC</span>
            </div>
            <div>
                <b>Support</b>
                <span>Metro/tier-1 engineers plus local vendor partners</span>
            </div>
        </div>
    </div>
</section>

<section class="section" id="support">
    <div class="container">
        <div class="section-head">
            <span class="eyebrow">Support Model</span>
            <h2>One Point of Contact. Four Ways to Reach Us.</h2>
        </div>

        <div class="support-grid large">
            <div>
                <b>Dedicated point of contact</b>
                <span>Commercial requests, new device requirements, escalations and reviews.</span>
            </div>
            <div>
                <b>Helpdesk</b>
                <span>Logged technical issues with tracked status and resolution history.</span>
            </div>
            <div>
                <b>WhatsApp support group</b>
                <span>Immediate coordination, quick queries and delivery updates.</span>
            </div>
            <div>
                <b>On-site engineer</b>
                <span>Hardware faults, rollouts, floor setups and user-side installation.</span>
            </div>
        </div>

        <div class="response-badge">
            First response on website enquiries: within one working day •
            WhatsApp response: <?= e(setting('whatsapp_response_minutes', '[confirm]')) ?>
            minutes during business hours •
            On-site: <?= e(setting('support_ticket_hours', '[confirm]')) ?> hours in serviced cities
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
