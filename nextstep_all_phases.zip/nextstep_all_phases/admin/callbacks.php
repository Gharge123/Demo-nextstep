<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Callbacks';
$rows = db()->query('SELECT * FROM callbacks ORDER BY id DESC')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
	<h2>Callback Requests</h2>

	<table>
		<tr>
			<th>Name</th>
			<th>Phone</th>
			<th>Preferred time</th>
			<th>Status</th>
			<th>Date</th>
		</tr>
		<?php foreach ($rows as $row): ?>
			<tr>
				<td><?= e($row['name']) ?></td>
				<td>
					<a href="tel:<?= e($row['phone']) ?>">
						<?= e($row['phone']) ?>
					</a>
				</td>
				<td><?= e($row['preferred_time']) ?></td>
				<td><?= e($row['status']) ?></td>
				<td><?= e($row['created_at']) ?></td>
			</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>