<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Settings';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    foreach ($_POST['settings'] ?? [] as $key => $value) {
        $statement = $pdo->prepare(
            'INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)'
        );
        $statement->execute([$key, trim($value)]);
    }

    flash('success', 'Settings saved.');
    redirect('admin/settings.php');
}

$settings = [];
foreach ($pdo->query('SELECT * FROM settings') as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$fields = [
    'sales_email' => 'Sales email',
    'support_email' => 'Support email',
    'business_hours' => 'Business hours',
    'gstin' => 'GSTIN',
    'registration_no' => 'Company registration number',
    'devices_deployed' => 'Devices deployed',
    'clients_count' => 'Business clients',
    'cities_covered' => 'Cities covered',
    'uptime' => 'Device uptime',
    'years_operation' => 'Years in operation',
    'replacement_hours' => 'Replacement turnaround hours',
    'whatsapp_response_minutes' => 'WhatsApp response minutes',
    'support_ticket_hours' => 'Support acknowledgement hours',
    'bulk_quote_days' => 'Bulk quote days',
    'standard_build_days' => 'Standard build days',
    'founding_year' => 'Founding year / milestones',
    'buyout_policy' => 'Buyout policy',
    'google_rating' => 'Google rating',
    'google_review_count' => 'Google review count',
    'google_maps_url' => 'Google Maps URL',
    'linkedin' => 'LinkedIn URL',
    'instagram' => 'Instagram URL',
    'facebook' => 'Facebook URL',
    'youtube' => 'YouTube URL',
];

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2>Business & Launch Settings</h2>
    <p>
        Fill every <b>[confirm]</b> value before publishing. These settings feed the public site and footer.
    </p>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

        <div class="grid2">
            <?php foreach ($fields as $key => $label): ?>
                <label>
                    <?= e($label) ?>
                    <input
                        name="settings[<?= e($key) ?>]"
                        value="<?= e($settings[$key] ?? '') ?>"
                    >
                </label>
            <?php endforeach; ?>
        </div>

        <button>Save Settings</button>
    </form>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>