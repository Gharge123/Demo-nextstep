<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Testimonials';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int) ($_POST['id'] ?? 0);
    $testimonialData = [
        trim($_POST['name']),
        trim($_POST['designation']),
        trim($_POST['company']),
        trim($_POST['city']),
        trim($_POST['quote']),
        trim($_POST['logo']),
        trim($_POST['status']),
    ];

    if ($id) {
        $q = $pdo->prepare(
            'UPDATE testimonials SET name=?,designation=?,company=?,city=?,quote=?,logo=?,status=? WHERE id=?'
        );
        $q->execute([...$testimonialData, $id]);
    } else {
        $q = $pdo->prepare(
            'INSERT INTO testimonials(name,designation,company,city,quote,logo,status) VALUES(?,?,?,?,?,?,?)'
        );
        $q->execute($testimonialData);
    }

    redirect('admin/testimonials.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM testimonials WHERE id = ?');
    $q->execute([(int) $_GET['edit']]);
    $edit = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM testimonials ORDER BY id')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2>Testimonial</h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <div class="grid2">
            <label>
                Name
                <input name="name" value="<?= e($edit['name'] ?? '') ?>" required>
            </label>

            <label>
                Designation
                <input name="designation" value="<?= e($edit['designation'] ?? '') ?>">
            </label>

            <label>
                Company
                <input name="company" value="<?= e($edit['company'] ?? '') ?>">
            </label>

            <label>
                City
                <input name="city" value="<?= e($edit['city'] ?? '') ?>">
            </label>

            <label>
                Logo URL
                <input name="logo" value="<?= e($edit['logo'] ?? '') ?>">
            </label>

            <label>
                Status
                <select name="status">
                    <option>active</option>
                    <option <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>inactive</option>
                </select>
            </label>
        </div>

        <label>
            Quote
            <textarea name="quote" required><?= e($edit['quote'] ?? '') ?></textarea>
        </label>

        <button>Save</button>
    </form>
</div>

<div class="panel">
    <table>
        <tr>
            <th>Name</th>
            <th>Company</th>
            <th>City</th>
            <th></th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['company']) ?></td>
                <td><?= e($row['city']) ?></td>
                <td><a href="?edit=<?= $row['id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>