<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Industries';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int) ($_POST['id'] ?? 0);
    $industryData = [
        trim($_POST['name']),
        trim($_POST['challenge']),
        trim($_POST['what_we_provide']),
        trim($_POST['recommended_devices']),
        trim($_POST['outcome']),
        (int) $_POST['sort_order'],
        trim($_POST['status']),
    ];

    if ($id) {
        $q = $pdo->prepare(
            'UPDATE industries SET name=?,challenge=?,what_we_provide=?,recommended_devices=?,outcome=?,sort_order=?,status=? WHERE id=?'
        );
        $q->execute([...$industryData, $id]);
    } else {
        $q = $pdo->prepare(
            'INSERT INTO industries(name,challenge,what_we_provide,recommended_devices,outcome,sort_order,status) VALUES(?,?,?,?,?,?,?)'
        );
        $q->execute($industryData);
    }

    redirect('admin/industries.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM industries WHERE id = ?');
    $q->execute([(int) $_GET['edit']]);
    $edit = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM industries ORDER BY sort_order')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2><?= $edit ? 'Edit' : 'Add' ?> Industry</h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <label>
            Name
            <input name="name" value="<?= e($edit['name'] ?? '') ?>" required>
        </label>

        <label>
            Challenge
            <textarea name="challenge"><?= e($edit['challenge'] ?? '') ?></textarea>
        </label>

        <label>
            What we provide
            <textarea name="what_we_provide"><?= e($edit['what_we_provide'] ?? '') ?></textarea>
        </label>

        <label>
            Recommended devices
            <textarea name="recommended_devices"><?= e($edit['recommended_devices'] ?? '') ?></textarea>
        </label>

        <label>
            Outcome
            <textarea name="outcome"><?= e($edit['outcome'] ?? '') ?></textarea>
        </label>

        <label>
            Sort
            <input type="number" name="sort_order" value="<?= e($edit['sort_order'] ?? 1) ?>">
        </label>

        <label>
            Status
            <select name="status">
                <option>active</option>
                <option <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>inactive</option>
            </select>
        </label>

        <button>Save</button>
    </form>
</div>

<div class="panel">
    <h2>Industries</h2>

    <table>
        <tr>
            <th>Name</th>
            <th>Status</th>
            <th></th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['status']) ?></td>
                <td><a href="?edit=<?= $row['id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>