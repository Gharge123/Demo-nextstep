<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Dashboard';
$pdo = db();
$counts = [
	'enquiries' => $pdo->query('SELECT COUNT(*) FROM enquiries')->fetchColumn(),
	'callbacks' => $pdo->query('SELECT COUNT(*) FROM callbacks')->fetchColumn(),
	'posts' => $pdo->query("SELECT COUNT(*) FROM posts WHERE status = 'published'")->fetchColumn(),
	'whatsapp' => $pdo->query("SELECT COUNT(*) FROM leads_events WHERE event_type = 'whatsapp'")->fetchColumn(),
	'calls' => $pdo->query("SELECT COUNT(*) FROM leads_events WHERE event_type = 'call'")->fetchColumn(),
];

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="cards">
	<?php foreach ($counts as $key => $value): ?>
		<div class="stat">
			<b><?= e($value) ?></b>
			<span><?= e(ucwords($key)) ?></span>
		</div>
	<?php endforeach; ?>
</div>

<div class="panel">
	<h2>Phase 1 Launch Controls</h2>
	<ul>
		<li>Manage devices, industries, blog articles, testimonials and client logo placeholders.</li>
		<li>Review rental enquiries and callback requests.</li>
		<li>Update all client [confirm] values in Settings before launch.</li>
		<li>Configure optional CRM webhook, GA4 and social links in config/settings.</li>
	</ul>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>