<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pdo = db();
$section = $_GET['section'] ?? 'assets';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	verify_csrf();
	$action = $_POST['action'] ?? '';

	try {
		if ($action === 'user') {
			if (!empty($_POST['id'])) {
				$q = $pdo->prepare(
					'UPDATE portal_users SET company_name=?,contact_name=?,email=?,phone=?,status=? WHERE id=?'
				);
				$q->execute([
					$_POST['company_name'],
					$_POST['contact_name'],
					$_POST['email'],
					$_POST['phone'],
					$_POST['status'],
					$_POST['id'],
				]);
			} else {
				$q = $pdo->prepare(
					'INSERT INTO portal_users(company_name,contact_name,email,phone,password) VALUES(?,?,?,?,?)'
				);
				$q->execute([
					$_POST['company_name'],
					$_POST['contact_name'],
					$_POST['email'],
					$_POST['phone'],
					password_hash($_POST['password'], PASSWORD_DEFAULT),
				]);
			}
		} elseif ($action === 'asset') {
			$q = $pdo->prepare(
				'INSERT INTO assets(portal_user_id,asset_tag,device_name,serial_number,category,brand,configuration,holder_name,location,rental_start,rental_end,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'
			);
			$q->execute([
				(int) $_POST['portal_user_id'],
				$_POST['asset_tag'],
				$_POST['device_name'],
				$_POST['serial_number'],
				$_POST['category'],
				$_POST['brand'],
				$_POST['configuration'],
				$_POST['holder_name'],
				$_POST['location'],
				$_POST['rental_start'] ?: null,
				$_POST['rental_end'] ?: null,
				$_POST['status'],
			]);
		} elseif ($action === 'ticket') {
			$q = $pdo->prepare('UPDATE tickets SET status=?,assigned_to=?,resolution=? WHERE id=?');
			$q->execute([
				$_POST['status'],
				$_POST['assigned_to'],
				$_POST['resolution'],
				(int) $_POST['id'],
			]);
		} elseif ($action === 'city') {
			$q = $pdo->prepare(
				'INSERT INTO cities(name,slug,region,headline,intro,coverage,devices,support,meta_title,meta_description) VALUES(?,?,?,?,?,?,?,?,?,?)'
			);
			$q->execute([
				$_POST['name'],
				clean_slug($_POST['slug']),
				$_POST['region'],
				$_POST['headline'],
				$_POST['intro'],
				$_POST['coverage'],
				$_POST['devices'],
				$_POST['support'],
				$_POST['meta_title'],
				$_POST['meta_description'],
			]);
		} elseif ($action === 'price') {
			$q = $pdo->prepare(
				'INSERT INTO calculator_prices(device_type,monthly_price,minimum_months,active) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE monthly_price=VALUES(monthly_price),minimum_months=VALUES(minimum_months),active=VALUES(active)'
			);
			$q->execute([
				$_POST['device_type'],
				(float) $_POST['monthly_price'],
				(int) $_POST['minimum_months'],
				isset($_POST['active']) ? 1 : 0,
			]);
		}

		$message = 'Saved successfully.';
	} catch (Throwable $e) {
		$message = 'Error: ' . $e->getMessage();
	}
}

$users = $pdo->query('SELECT * FROM portal_users ORDER BY created_at DESC')->fetchAll();
$assets = $pdo->query(
	'SELECT a.*,p.company_name FROM assets a JOIN portal_users p ON p.id=a.portal_user_id ORDER BY a.created_at DESC'
)->fetchAll();
$tickets = $pdo->query(
	'SELECT t.*,p.company_name FROM tickets t JOIN portal_users p ON p.id=t.portal_user_id ORDER BY t.updated_at DESC'
)->fetchAll();
$cities = $pdo->query('SELECT * FROM cities ORDER BY name')->fetchAll();
$prices = $pdo->query('SELECT * FROM calculator_prices ORDER BY device_type')->fetchAll();
$downloads = $pdo->query(
	'SELECT * FROM profile_downloads ORDER BY created_at DESC LIMIT 100'
)->fetchAll();
$chats = $pdo->query(
	'SELECT * FROM chat_messages ORDER BY created_at DESC LIMIT 100'
)->fetchAll();

$title = 'Phase 2 & 3 Operations';
include __DIR__ . '/../includes/admin_header.php';
?>

<?php if ($message): ?>
	<div class="alert success"><?= e($message) ?></div>
<?php endif; ?>

<div class="tabs">
	<a href="?section=users">Portal Users</a>
	<a href="?section=assets">Assets</a>
	<a href="?section=tickets">Helpdesk</a>
	<a href="?section=cities">Cities</a>
	<a href="?section=prices">Calculator</a>
	<a href="?section=downloads">Profile Leads</a>
	<a href="?section=chats">Live Chat</a>
</div>

<?php if ($section === 'users'): ?>
	<div class="panel">
		<h2>Create Client Portal User</h2>
		<form method="post">
			<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
			<input type="hidden" name="action" value="user">
			<input name="company_name" placeholder="Company" required>
			<input name="contact_name" placeholder="Contact" required>
			<input type="email" name="email" placeholder="Email" required>
			<input name="phone" placeholder="Phone">
			<input type="password" name="password" placeholder="Password" required>
			<button class="btn">Create</button>
		</form>
	</div>

	<div class="panel">
		<h2>Portal Users</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Company</th>
					<th>Contact</th>
					<th>Email</th>
					<th>Status</th>
				</tr>
				<?php foreach ($users as $user): ?>
					<tr>
						<td><?= e($user['company_name']) ?></td>
						<td><?= e($user['contact_name']) ?></td>
						<td><?= e($user['email']) ?></td>
						<td><?= e($user['status']) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php elseif ($section === 'assets'): ?>
	<div class="panel">
		<h2>Add Asset</h2>
		<form method="post">
			<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
			<input type="hidden" name="action" value="asset">
			<select name="portal_user_id" required>
				<option value="">Client</option>
				<?php foreach ($users as $user): ?>
					<option value="<?= e($user['id']) ?>"><?= e($user['company_name']) ?></option>
				<?php endforeach; ?>
			</select>
			<input name="asset_tag" placeholder="Asset Tag" required>
			<input name="device_name" placeholder="Device" required>
			<input name="serial_number" placeholder="Serial">
			<input name="category" placeholder="Category">
			<input name="brand" placeholder="Brand">
			<input name="configuration" placeholder="Configuration">
			<input name="holder_name" placeholder="Holder">
			<input name="location" placeholder="Location">
			<input type="date" name="rental_start">
			<input type="date" name="rental_end">
			<select name="status">
				<option>deployed</option>
				<option>available</option>
				<option>repair</option>
				<option>returned</option>
			</select>
			<button class="btn">Add Asset</button>
		</form>
	</div>

	<div class="panel">
		<h2>Assets</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Tag</th>
					<th>Company</th>
					<th>Device</th>
					<th>Holder</th>
					<th>Status</th>
				</tr>
				<?php foreach ($assets as $asset): ?>
					<tr>
						<td><?= e($asset['asset_tag']) ?></td>
						<td><?= e($asset['company_name']) ?></td>
						<td><?= e($asset['device_name']) ?></td>
						<td><?= e($asset['holder_name']) ?></td>
						<td><?= e($asset['status']) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php elseif ($section === 'tickets'): ?>
	<div class="panel">
		<h2>Helpdesk Tickets</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>#</th>
					<th>Company</th>
					<th>Subject</th>
					<th>Priority</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
				<?php foreach ($tickets as $ticket): ?>
					<tr>
						<td><?= e($ticket['id']) ?></td>
						<td><?= e($ticket['company_name']) ?></td>
						<td><?= e($ticket['subject']) ?></td>
						<td><?= e($ticket['priority']) ?></td>
						<td><?= e($ticket['status']) ?></td>
						<td>
							<form method="post">
								<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
								<input type="hidden" name="action" value="ticket">
								<input type="hidden" name="id" value="<?= e($ticket['id']) ?>">
								<select name="status">
									<option>open</option>
									<option>in_progress</option>
									<option>waiting_customer</option>
									<option>resolved</option>
									<option>closed</option>
								</select>
								<input name="assigned_to" placeholder="Owner" value="<?= e($ticket['assigned_to']) ?>">
								<input name="resolution" placeholder="Resolution" value="<?= e($ticket['resolution']) ?>">
								<button>Update</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php elseif ($section === 'cities'): ?>
	<div class="panel">
		<h2>Add City Landing Page</h2>
		<form method="post">
			<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
			<input type="hidden" name="action" value="city">
			<?php foreach (['name', 'slug', 'region', 'headline', 'intro', 'coverage', 'devices', 'support', 'meta_title', 'meta_description'] as $field): ?>
				<input
					name="<?= e($field) ?>"
					placeholder="<?= e(ucwords(str_replace('_', ' ', $field))) ?>"
					required
				>
			<?php endforeach; ?>
			<button class="btn">Create City Page</button>
		</form>
	</div>

	<div class="panel">
		<h2>City Pages</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>City</th>
					<th>Slug</th>
					<th>URL</th>
				</tr>
				<?php foreach ($cities as $city): ?>
					<tr>
						<td><?= e($city['name']) ?></td>
						<td><?= e($city['slug']) ?></td>
						<td>
							<a target="_blank" href="<?= url('city.php?slug=' . rawurlencode($city['slug'])) ?>">
								Open
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php elseif ($section === 'prices'): ?>
	<div class="panel">
		<h2>Calculator Pricing</h2>
		<form method="post">
			<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
			<input type="hidden" name="action" value="price">
			<input name="device_type" placeholder="Device type" required>
			<input type="number" step="0.01" name="monthly_price" placeholder="Monthly price" required>
			<input type="number" min="1" name="minimum_months" value="1">
			<label><input type="checkbox" name="active" checked> Active</label>
			<button class="btn">Save Price</button>
		</form>

		<div class="table-wrap">
			<table>
				<tr>
					<th>Device</th>
					<th>Monthly</th>
					<th>Min Term</th>
					<th>Active</th>
				</tr>
				<?php foreach ($prices as $price): ?>
					<tr>
						<td><?= e($price['device_type']) ?></td>
						<td>₹<?= number_format($price['monthly_price']) ?></td>
						<td><?= e($price['minimum_months']) ?></td>
						<td><?= e($price['active']) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php elseif ($section === 'downloads'): ?>
	<div class="panel">
		<h2>Company Profile Leads</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Name</th>
					<th>Company</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Date</th>
				</tr>
				<?php foreach ($downloads as $download): ?>
					<tr>
						<td><?= e($download['name']) ?></td>
						<td><?= e($download['company']) ?></td>
						<td><?= e($download['email']) ?></td>
						<td><?= e($download['phone']) ?></td>
						<td><?= e($download['created_at']) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

<?php else: ?>
	<div class="panel">
		<h2>Live Chat Conversations</h2>
		<div class="table-wrap">
			<table>
				<tr>
					<th>Session</th>
					<th>Message</th>
					<th>Reply</th>
					<th>Date</th>
				</tr>
				<?php foreach ($chats as $chat): ?>
					<tr>
						<td><?= e($chat['session_id']) ?></td>
						<td><?= e($chat['message']) ?></td>
						<td><?= e($chat['reply']) ?></td>
						<td><?= e($chat['created_at']) ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>
