<?php
require_once __DIR__ . '/../config/db.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: ' . url('admin/index.php'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $statement = db()->prepare('SELECT * FROM admins WHERE email=? LIMIT 1');
    $statement->execute([trim($_POST['email'] ?? '')]);
    $admin = $statement->fetch();

    if ($admin && password_verify($_POST['password'] ?? '', $admin['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        header('Location: ' . url('admin/index.php'));
        exit;
    }

    $error = 'Invalid email or password.';
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login</title>
    <link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>">
</head>
<body class="login">
    <form method="post" class="login-card">
        <h1>Next Step Admin</h1>

        <?php if (isset($error)): ?>
            <div class="error"><?= e($error) ?></div>
        <?php endif; ?>

        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

        <label>
            Email
            <input type="email" name="email" required>
        </label>

        <label>
            Password
            <input type="password" name="password" required>
        </label>

        <button>Login</button>
        <p>Change the initial password immediately after installation.</p>
    </form>
</body>
</html>
