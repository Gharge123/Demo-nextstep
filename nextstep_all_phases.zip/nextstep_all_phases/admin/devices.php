<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Devices';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int) ($_POST['id'] ?? 0);
    $deviceData = [
        trim($_POST['name']),
        trim($_POST['category']),
        trim($_POST['brand']),
        trim($_POST['specs']),
        trim($_POST['use_case']),
        $_POST['price'] !== '' ? $_POST['price'] : null,
        trim($_POST['accessories']),
        trim($_POST['image']),
        isset($_POST['featured']) ? 1 : 0,
        trim($_POST['status']),
    ];

    if ($id) {
        $q = $pdo->prepare(
            'UPDATE devices SET name=?,category=?,brand=?,specs=?,use_case=?,price=?,accessories=?,image=?,featured=?,status=? WHERE id=?'
        );
        $q->execute([...$deviceData, $id]);
    } else {
        $q = $pdo->prepare(
            'INSERT INTO devices(name,category,brand,specs,use_case,price,accessories,image,featured,status) VALUES(?,?,?,?,?,?,?,?,?,?)'
        );
        $q->execute($deviceData);
    }

    flash('success', 'Device saved.');
    redirect('admin/devices.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM devices WHERE id = ?');
    $q->execute([(int) $_GET['edit']]);
    $edit = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM devices ORDER BY id DESC')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2><?= $edit ? 'Edit' : 'Add' ?> Device</h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <div class="grid2">
            <label>
                Name
                <input name="name" value="<?= e($edit['name'] ?? '') ?>" required>
            </label>

            <label>
                Category
                <input name="category" value="<?= e($edit['category'] ?? '') ?>" required>
            </label>

            <label>
                Brand
                <input name="brand" value="<?= e($edit['brand'] ?? '') ?>">
            </label>

            <label>
                Price/month
                <input name="price" value="<?= e($edit['price'] ?? '') ?>">
            </label>

            <label>
                Use case
                <input name="use_case" value="<?= e($edit['use_case'] ?? '') ?>">
            </label>

            <label>
                Image URL
                <input name="image" value="<?= e($edit['image'] ?? '') ?>">
            </label>
        </div>

        <label>
            Specs
            <textarea name="specs" required><?= e($edit['specs'] ?? '') ?></textarea>
        </label>

        <label>
            Accessories
            <textarea name="accessories"><?= e($edit['accessories'] ?? '') ?></textarea>
        </label>

        <label>
            Status
            <select name="status">
                <option>active</option>
                <option <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>inactive</option>
            </select>
        </label>

        <label>
            <input type="checkbox" name="featured" <?= !empty($edit['featured']) ? 'checked' : '' ?>>
            Featured
        </label>

        <button>Save Device</button>
    </form>
</div>

<div class="panel">
    <h2>Catalog</h2>

    <table>
        <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Brand</th>
            <th>Status</th>
            <th></th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['category']) ?></td>
                <td><?= e($row['brand']) ?></td>
                <td><?= e($row['status']) ?></td>
                <td><a href="?edit=<?= $row['id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>