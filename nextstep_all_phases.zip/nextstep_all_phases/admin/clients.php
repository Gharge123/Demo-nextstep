<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Clients';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int) ($_POST['id'] ?? 0);
    $clientData = [
        trim($_POST['name']),
        trim($_POST['logo']),
        trim($_POST['status']),
        (int) $_POST['sort_order'],
    ];

    if ($id) {
        $q = $pdo->prepare('UPDATE clients SET name=?,logo=?,status=?,sort_order=? WHERE id=?');
        $q->execute([...$clientData, $id]);
    } else {
        $q = $pdo->prepare('INSERT INTO clients(name,logo,status,sort_order) VALUES(?,?,?,?)');
        $q->execute($clientData);
    }

    redirect('admin/clients.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM clients WHERE id = ?');
    $q->execute([(int) $_GET['edit']]);
    $edit = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM clients ORDER BY sort_order')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2>Client Logo</h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <label>
            Name
            <input name="name" value="<?= e($edit['name'] ?? '') ?>" required>
        </label>

        <label>
            Logo URL
            <input name="logo" value="<?= e($edit['logo'] ?? '') ?>">
        </label>

        <label>
            Sort
            <input type="number" name="sort_order" value="<?= e($edit['sort_order'] ?? 1) ?>">
        </label>

        <label>
            Status
            <select name="status">
                <option>active</option>
                <option <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>inactive</option>
            </select>
        </label>

        <button>Save</button>
    </form>
</div>

<div class="panel">
    <table>
        <tr>
            <th>Name</th>
            <th>Logo</th>
            <th></th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['logo']) ?></td>
                <td><a href="?edit=<?= $row['id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>