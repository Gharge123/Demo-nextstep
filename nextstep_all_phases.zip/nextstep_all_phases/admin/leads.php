<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Leads';
$pdo = db();

if (isset($_GET['status'], $_GET['id'])) {
    $statusUpdate = $pdo->prepare('UPDATE enquiries SET status=? WHERE id=?');
    $statusUpdate->execute([$_GET['status'], (int) $_GET['id']]);
    redirect('admin/leads.php');
}

$rows = $pdo->query('SELECT * FROM enquiries ORDER BY id DESC')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2>Rental Enquiries</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Segment</th>
            <th>Requirement</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['id']) ?></td>
                <td>
                    <?= e($row['name']) ?><br>
                    <?= e($row['company']) ?>
                </td>
                <td>
                    <a href="mailto:<?= e($row['email']) ?>">
                        <?= e($row['email']) ?>
                    </a><br>
                    <a href="tel:<?= e($row['phone']) ?>">
                        <?= e($row['phone']) ?>
                    </a>
                </td>
                <td><?= e($row['segment']) ?></td>
                <td>
                    <?= e($row['devices']) ?><br>
                    Qty <?= e($row['quantity']) ?> · <?= e($row['duration']) ?><br>
                    <?= e($row['city']) ?><br>
                    <?= e($row['requirements']) ?>
                </td>
                <td>
                    <select onchange="location='?id=<?= $row['id'] ?>&status='+this.value">
                        <option <?= $row['status'] === 'new' ? 'selected' : '' ?>>new</option>
                        <option <?= $row['status'] === 'contacted' ? 'selected' : '' ?>>contacted</option>
                        <option <?= $row['status'] === 'qualified' ? 'selected' : '' ?>>qualified</option>
                        <option <?= $row['status'] === 'quoted' ? 'selected' : '' ?>>quoted</option>
                        <option <?= $row['status'] === 'won' ? 'selected' : '' ?>>won</option>
                        <option <?= $row['status'] === 'lost' ? 'selected' : '' ?>>lost</option>
                    </select>
                </td>
                <td><?= e($row['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>