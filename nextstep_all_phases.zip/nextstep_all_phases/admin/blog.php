<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$title = 'Blog';
$pdo = db();

if (isset($_GET['delete'])) {
    $q = $pdo->prepare('DELETE FROM posts WHERE id = ?');
    $q->execute([(int) $_GET['delete']]);
    redirect('admin/blog.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int) ($_POST['id'] ?? 0);
    $titleValue = trim($_POST['title']);
    $slug = slugify($_POST['slug'] ?: $titleValue);
    $status = trim($_POST['status']);
    $publishedAt = $status === 'published'
        ? (($_POST['published_at'] ?? '') ?: date('Y-m-d H:i:s'))
        : null;
    $postData = [
        $titleValue,
        $slug,
        trim($_POST['category']),
        trim($_POST['excerpt']),
        $_POST['content'],
        trim($_POST['cover_image']),
        trim($_POST['read_time']),
        trim($_POST['meta_title']),
        trim($_POST['meta_description']),
        $status,
        $publishedAt,
    ];

    if ($id) {
        $q = $pdo->prepare(
            'UPDATE posts SET title=?,slug=?,category=?,excerpt=?,content=?,cover_image=?,read_time=?,meta_title=?,meta_description=?,status=?,published_at=? WHERE id=?'
        );
        $q->execute([...$postData, $id]);
    } else {
        $q = $pdo->prepare(
            'INSERT INTO posts(title,slug,category,excerpt,content,cover_image,read_time,meta_title,meta_description,status,published_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)'
        );
        $q->execute($postData);
    }

    redirect('admin/blog.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM posts WHERE id = ?');
    $q->execute([(int) $_GET['edit']]);
    $edit = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM posts ORDER BY id DESC')->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="panel">
    <h2><?= $edit ? 'Edit' : 'Add' ?> Article</h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <label>
            Title
            <input name="title" value="<?= e($edit['title'] ?? '') ?>" required>
        </label>

        <div class="grid2">
            <label>
                Slug
                <input name="slug" value="<?= e($edit['slug'] ?? '') ?>">
            </label>

            <label>
                Category
                <input name="category" value="<?= e($edit['category'] ?? '') ?>" required>
            </label>

            <label>
                Read time
                <input name="read_time" value="<?= e($edit['read_time'] ?? '5 min read') ?>">
            </label>

            <label>
                Cover image URL
                <input name="cover_image" value="<?= e($edit['cover_image'] ?? '') ?>">
            </label>

            <label>
                Meta title
                <input name="meta_title" value="<?= e($edit['meta_title'] ?? '') ?>">
            </label>

            <label>
                Meta description
                <input name="meta_description" value="<?= e($edit['meta_description'] ?? '') ?>">
            </label>
        </div>

        <label>
            Excerpt
            <textarea name="excerpt"><?= e($edit['excerpt'] ?? '') ?></textarea>
        </label>

        <label>
            Content (HTML)
            <textarea name="content" rows="14"><?= e($edit['content'] ?? '') ?></textarea>
        </label>

        <label>
            Status
            <select name="status">
                <option>draft</option>
                <option <?= ($edit['status'] ?? '') === 'published' ? 'selected' : '' ?>>published</option>
            </select>
        </label>

        <button>Save Article</button>
    </form>
</div>

<div class="panel">
    <h2>Articles</h2>

    <table>
        <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th></th>
        </tr>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e($row['title']) ?></td>
                <td><?= e($row['category']) ?></td>
                <td><?= e($row['status']) ?></td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>">Edit</a>
                    ·
                    <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include __DIR__ . '/../includes/admin_footer.php'; ?>