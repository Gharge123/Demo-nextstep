<?php

require_once __DIR__ . '/config/db.php';

$metaTitle = 'DaaS & Device Rental Insights | Next Step Resources';
$metaDescription = 'Guides on device rental, DaaS, OPEX vs CAPEX, startup IT setup and remote workforce deployment from the Next Step team.';
$category = trim($_GET['category'] ?? '');

if ($category !== '') {
    $statement = db()->prepare(
        "SELECT * FROM posts
         WHERE status = 'published'
           AND category = :category
         ORDER BY published_at DESC, id DESC"
    );

    $statement->execute([
        ':category' => $category,
    ]);
} else {
    $statement = db()->query(
        "SELECT * FROM posts
         WHERE status = 'published'
         ORDER BY published_at DESC, id DESC"
    );
}

$posts = $statement->fetchAll();

$categories = db()
    ->query(
        "SELECT DISTINCT category
         FROM posts
         WHERE status = 'published'
         ORDER BY category"
    )
    ->fetchAll(PDO::FETCH_COLUMN);

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Resources / Blog</span>
        <h1>Resources on Device Rental, IT Deployment and the DaaS Model</h1>
        <p>
            Practical guidance for IT managers, founders and operations teams making
            hardware decisions — plus rental guides for individuals in Pune.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="blog-top">
            <div>
                <h2>Featured & Latest</h2>
                <p>
                    Guides on DaaS, OPEX vs CAPEX, startup IT setup, remote workforce deployment,
                    device guides and Pune-local rentals.
                </p>
            </div>

            <form method="get" class="category-filter-form">

    <select
        name="category"
        class="category-select"
    >
        <option value="">
            All categories
        </option>

        <?php foreach ($categories as $item): ?>

            <option
                value="<?= e($item) ?>"
                <?= $category === $item ? 'selected' : '' ?>
            >
                <?= e($item) ?>
            </option>

        <?php endforeach; ?>

    </select>


    <button
        class="btn outline category-filter-btn"
        type="submit"
    >
        Filter
    </button>

</form>
        </div>

        <div class="blog-grid">
            <?php foreach ($posts as $post): ?>
                <article class="blog-card" data-fade>
                    <div class="blog-image">
                        <?php if ($post['cover_image']): ?>
                            <img
                                src="<?= e($post['cover_image']) ?>"
                                alt="<?= e($post['title']) ?>"
                                loading="lazy"
                            >
                        <?php else: ?>
                            <img
                                src="<?= url('assets/images/work-laptop.jpg') ?>"
                                alt="Next Step device rental resources"
                                loading="lazy"
                            >
                        <?php endif; ?>
                    </div>

                    <div>
                        <span class="tag">
                            <?= e($post['category']) ?>
                        </span>

                        <h2><?= e($post['title']) ?></h2>
                        <p><?= e($post['excerpt']) ?></p>

                        <small>
                            <?= e($post['read_time']) ?> ·
                            <?= e(date('d M Y', strtotime($post['published_at']))) ?>
                        </small>
<br>
                        <a
                            class="text-link"
                            href="<?= url('post.php?slug=' . urlencode($post['slug'])) ?>"
                        >
                            Read article →
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section muted">
    <div class="container newsletter">
        <div>
            <span class="eyebrow">Stay informed</span>
            <h2>Subscribe for Updates</h2>
            <p>Get practical device rental and IT deployment guidance.</p>
        </div>

        <form method="post" action="<?= url('actions/newsletter.php') ?>">
            <input
                type="hidden"
                name="csrf"
                value="<?= e(csrf_token()) ?>"
            >
            <input
                type="email"
                name="email"
                placeholder="Your email address"
                required
            >
            
            <button class="btn primary" type="submit">
                Subscribe
            </button>
        </form>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
