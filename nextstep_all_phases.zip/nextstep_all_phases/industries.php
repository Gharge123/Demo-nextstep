<?php
require_once __DIR__ . '/config/db.php';

$metaTitle = 'Device Rental for IT, BPO, Design & Education | Next Step';
$metaDescription = 'Industry-specific device rental for IT, startups, BPO, education, media, engineering and remote teams. Configured, delivered and supported across India.';
$rows = db()
	->query("SELECT * FROM industries WHERE status = 'active' ORDER BY sort_order, id")
	->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
	<div class="container">
		<span class="eyebrow">Industries We Serve</span>
		<h1>Device Rentals Built Around the Way Your Industry Works</h1>
		<p>
			A design studio, a BPO floor and a distributed engineering team need very different machines
			— and very different support. We configure and support each accordingly.
		</p>
		<a class="btn white" href="<?= url('contact.php?source=industry-quote') ?>">
			Request an Industry-Specific Quote
		</a>
	</div>
</section>

<section class="section">
	<div class="container">
		<p class="lead">
			Next Step supports organisations across sectors with rental hardware, deployment and managed support.
			The requirement is rarely just a laptop — it is the right configuration, delivered to the right city,
			configured to the right standard, and supported without disrupting the work.
		</p>

		<div class="industry-list">
			<?php foreach ($rows as $i => $r): ?>
				<article class="industry">
					<div class="industry-num">0<?= $i + 1 ?></div>
					<div>
						<h2><?= e($r['name']) ?></h2>

						<h4>Challenge</h4>
						<p><?= e($r['challenge']) ?></p>

						<h4>What we provide</h4>
						<p><?= e($r['what_we_provide']) ?></p>

						<h4>Recommended devices</h4>
						<p><?= e($r['recommended_devices']) ?></p>

						<h4>Outcome</h4>
						<p><?= e($r['outcome']) ?></p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section muted">
	<div class="container">
		<div class="section-head">
			<span class="eyebrow">Cross-industry capabilities</span>
			<h2>One Operating Model Across Every Sector</h2>
		</div>

		<div class="feature-grid">
			<?php
			$capabilities = [
				['Preconfigured deployment', 'OS, software, MDM, email and asset tagging before dispatch.'],
				['Nationwide delivery & pickup', 'Business rentals across India including direct-to-employee dispatch.'],
				['Remote & on-site support', 'Engineers and local vendor backup in tier-2 and tier-3 cities.'],
				['Asset tracking dashboard', 'A current view of inventory, users, cities and rental terms.'],
				['Dedicated point of contact', 'One accountable contact for every business client.'],
				['Flexible scaling', 'Add or return devices as team size and project load change.'],
			];

			foreach ($capabilities as $capability):
			?>
				<div class="feature">
					<h3><?= e($capability[0]) ?></h3>
					<p><?= e($capability[1]) ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="final-cta">
	<div class="container">
		<h2>Tell us your industry and team size</h2>
		<p>
			We will recommend the right configuration and send a rental quote within one working day.
		</p>
		<a class="btn white" href="<?= url('contact.php') ?>">Request a Quote</a>
	</div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
