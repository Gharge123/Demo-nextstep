<?php
require_once __DIR__ . '/includes/functions.php';

$cities = db()->query('SELECT * FROM cities WHERE status="active" ORDER BY name')->fetchAll();
$metaTitle = 'Device Rental Cities | Next Step';

include __DIR__ . '/includes/header.php';
?>

<div class="container section">
	<span class="eyebrow">Phase 3 — Growth</span>
	<h1>Device Rental by City</h1>
	<p>Programmatic city landing pages for local organic reach and enterprise conversations.</p>

	<div class="cards">
		<?php foreach ($cities as $city): ?>
			<div class="panel">
				<h2><?= e($city['name']) ?></h2>
				<p><?= e($city['intro']) ?></p>
				<a
					class="btn small"
					href="<?= url('city.php?slug=' . rawurlencode($city['slug'])) ?>"
				>
					View <?= e($city['name']) ?> page
				</a>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
