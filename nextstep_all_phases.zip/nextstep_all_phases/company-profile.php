<?php
require_once __DIR__ . '/includes/functions.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $normalizedPhone = preg_replace('/\D/', '', $phone);

    if (
        $name === ''
        || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || !preg_match('/^[0-9]{10}$/', $normalizedPhone)
    ) {
        $error = 'Please enter a valid name, email and 10-digit phone number.';
    } else {
        $statement = db()->prepare(
            'INSERT INTO profile_downloads(name,company,email,phone) VALUES(?,?,?,?)'
        );
        $statement->execute([$name, $company, $email, $normalizedPhone]);
        log_event('profile_download', 'company-profile');
        $message = 'Thank you. Your company profile is ready.';
    }
}

$metaTitle = 'Company Profile | Next Step';
include __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <div class="form-card narrow">
        <span class="eyebrow">Procurement Resource</span>
        <h1>Download the Next Step Company Profile</h1>
        <p>
            Get a concise overview of our Device-as-a-Service model, deployment, support, logistics and device
            categories.
        </p>

        <?php if ($message): ?>
            <div class="alert success"><?= e($message) ?></div>
            <a class="btn" href="<?= url('downloads/next-step-company-profile.pdf') ?>" target="_blank">
                Download PDF Profile
            </a>
        <?php else: ?>
            <?php if ($error): ?>
                <div class="alert error"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

                <label>
                    Name
                    <input name="name" required>
                </label>

                <label>
                    Company
                    <input name="company">
                </label>

                <label>
                    Business Email
                    <input type="email" name="email" required>
                </label>

                <label>
                    Phone
                    <input
                        name="phone"
                        inputmode="numeric"
                        pattern="[0-9]{10}"
                        maxlength="10"
                        required
                    >
                </label>

                <button class="btn">Get Company Profile</button>
                <small>Your details are never shared with third parties.</small>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
