<?php
require_once __DIR__ . '/config/db.php';

$hash = password_hash('ChangeMe@123', PASSWORD_DEFAULT);
$statement = db()->prepare('UPDATE admins SET password=? WHERE email=?');
$statement->execute([$hash, 'admin@nextsteppune.com']);

echo 'Admin password set to ChangeMe@123. DELETE this file immediately.';

