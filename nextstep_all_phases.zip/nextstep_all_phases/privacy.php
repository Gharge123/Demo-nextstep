<?php
$metaTitle = 'Privacy Policy | Next Step';
$metaDescription = 'Privacy information for Next Step website enquiries.';

include __DIR__ . '/includes/header.php';
?>

<section class="page-hero">
	<div class="container">
		<span class="eyebrow">Privacy</span>
		<h1>Your details are never shared with third parties</h1>
		<p>
			Information submitted through this website is used to respond to rental, callback and resource
			requests.
		</p>
	</div>
</section>

<section class="section">
	<div class="container prose">
		<h2>Information we collect</h2>
		<p>
			Name, contact details, city, device requirements, rental duration and information you voluntarily
			provide in an enquiry.
		</p>

		<h2>How we use it</h2>
		<p>
			We use enquiry data to respond, qualify requirements, provide rental recommendations, route support
			and maintain our lead register.
		</p>

		<h2>Contact</h2>
		<p>For privacy questions, contact the support email configured in the website settings.</p>
	</div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>