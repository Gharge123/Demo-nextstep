<?php
require_once __DIR__ . '/includes/functions.php';

require_client();

$user = client_user();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $subject = trim($_POST['subject'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $priority = $_POST['priority'] ?? 'medium';
    $assetId = (int) ($_POST['asset_id'] ?? 0);

    if ($subject === '' || $description === '') {
        $error = 'Subject and description are required.';
    } elseif (!in_array($priority, ['low', 'medium', 'high', 'critical'], true)) {
        $error = 'Invalid priority.';
    } else {
        $asset = client_asset($assetId);
        $assetId = $asset ? $assetId : null;

        $statement = db()->prepare(
            'INSERT INTO tickets(portal_user_id,asset_id,subject,description,priority) VALUES(?,?,?,?,?)'
        );
        $statement->execute([$user['id'], $assetId, $subject, $description, $priority]);

        notify_email(
            SUPPORT_EMAIL,
            'New helpdesk ticket #' . db()->lastInsertId(),
            $subject . "\n\n" . $description
        );
        $message = 'Ticket created successfully.';
    }
}

$statement = db()->prepare(
    'SELECT id,asset_tag,device_name FROM assets WHERE portal_user_id=? ORDER BY asset_tag'
);
$statement->execute([$user['id']]);
$assets = $statement->fetchAll();

$metaTitle = 'Helpdesk | Next Step';
include __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <div class="form-card">
        <span class="eyebrow">Managed IT Support</span>
        <h1>Raise a Support Ticket</h1>
        <p>
            Use the helpdesk for tracked issues. For urgent escalation, use the WhatsApp support channel or your
            assigned point of contact.
        </p>

        <?php if ($message): ?>
            <div class="alert success"><?= e($message) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

            <label>
                Asset
                <select name="asset_id">
                    <option value="0">General issue</option>
                    <?php foreach ($assets as $asset): ?>
                        <option value="<?= e($asset['id']) ?>">
                            <?= e($asset['asset_tag'] . ' — ' . $asset['device_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                Subject
                <input name="subject" required>
            </label>

            <label>
                Priority
                <select name="priority">
                    <option>low</option>
                    <option selected>medium</option>
                    <option>high</option>
                    <option>critical</option>
                </select>
            </label>

            <label>
                Description
                <textarea name="description" rows="7" required></textarea>
            </label>

            <button class="btn">Submit Ticket</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
