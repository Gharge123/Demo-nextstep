<?php
require_once __DIR__ . '/includes/functions.php';

$prices = db()->query('SELECT * FROM calculator_prices WHERE active=1 ORDER BY device_type')->fetchAll();
$result = null;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $type = trim($_POST['device_type'] ?? '');
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    $duration = max(1, (int) ($_POST['duration'] ?? 1));

    $statement = db()->prepare(
        'SELECT * FROM calculator_prices WHERE device_type=? AND active=1'
    );
    $statement->execute([$type]);
    $price = $statement->fetch();

    if (
        !$price
        || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || !preg_match('/^[0-9]{10}$/', $phone)
        || $name === ''
        || $city === ''
    ) {
        $error = 'Please enter valid lead details and select a device.';
    } else {
        $monthly = (float) $price['monthly_price'] * $quantity;
        $result = [
            'monthly' => $monthly,
            'total' => $monthly * $duration,
            'minimum' => $price['minimum_months'],
        ];

        $statement = db()->prepare(
            'INSERT INTO calculator_requests(name,email,phone,city,device_type,quantity,duration,estimated_monthly) VALUES(?,?,?,?,?,?,?,?)'
        );
        $statement->execute([
            $name,
            $email,
            $phone,
            $city,
            $type,
            $quantity,
            $duration,
            $monthly,
        ]);

        log_event('calculator_lead', 'calculator');
        post_webhook([
            'type' => 'calculator_lead',
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'city' => $city,
            'device_type' => $type,
            'quantity' => $quantity,
            'duration' => $duration,
            'estimated_monthly' => $monthly,
        ]);
    }
}

$metaTitle = 'Rental Cost Calculator | Next Step';
$metaDescription = 'Estimate an indicative monthly rental for business devices and create a rental enquiry.';

include __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <div class="section-head">
        <div>
            <span class="eyebrow">Phase 3 — Growth</span>
            <h1>Rental Cost Calculator</h1>
            <p>
                Estimate an indicative monthly rental using device type × quantity × duration. Final pricing
                depends on configuration, term and availability.
            </p>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($result): ?>
        <div class="panel">
            <h2>Indicative estimate</h2>

            <div class="cards">
                <div class="stat">
                    <b>₹<?= number_format($result['monthly']) ?></b>
                    <span>Estimated monthly</span>
                </div>
                <div class="stat">
                    <b>₹<?= number_format($result['total']) ?></b>
                    <span>Estimated <?= e($_POST['duration']) ?>-month total</span>
                </div>
            </div>

            <p>
                Minimum suggested term for this device: <?= e($result['minimum']) ?> month(s). A sales
                representative will confirm the final quote.
            </p>
            <a class="btn" href="<?= url('contact.php') ?>">Request Final Quote</a>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

            <div class="form-grid">
                <label>
                    Name
                    <input name="name" required>
                </label>

                <label>
                    Business Email
                    <input type="email" name="email" required>
                </label>

                <label>
                    Phone
                    <input name="phone" maxlength="10" pattern="[0-9]{10}" required>
                </label>

                <label>
                    City
                    <input name="city" required>
                </label>

                <label>
                    Device Type
                    <select name="device_type" required>
                        <option value="">Select</option>
                        <?php foreach ($prices as $price): ?>
                            <option value="<?= e($price['device_type']) ?>">
                                <?= e($price['device_type']) ?> — from ₹<?= number_format($price['monthly_price']) ?>/month
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Quantity
                    <input type="number" min="1" max="5000" name="quantity" value="1" required>
                </label>

                <label>
                    Duration (months)
                    <input type="number" min="1" max="36" name="duration" value="3" required>
                </label>
            </div>

            <button class="btn">Calculate Estimate</button>
        </form>
    </div>

    <p>
        <small>
            Indicative figures only. Pricing is subject to configuration, quantity, rental terms, taxes and
            availability.
        </small>
    </p>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
