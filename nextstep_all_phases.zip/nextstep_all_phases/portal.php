<?php
require_once __DIR__ . '/includes/functions.php';

require_client();

$user = client_user();

$statement = db()->prepare('SELECT * FROM assets WHERE portal_user_id=? ORDER BY status,asset_tag');
$statement->execute([$user['id']]);
$assets = $statement->fetchAll();

$statement = db()->prepare(
	'SELECT * FROM tickets WHERE portal_user_id=? ORDER BY created_at DESC LIMIT 10'
);
$statement->execute([$user['id']]);
$tickets = $statement->fetchAll();

$metaTitle = 'Client Asset Portal | Next Step';
include __DIR__ . '/includes/header.php';
?>

<div class="container section">
	<div class="section-head">
		<div>
			<span class="eyebrow">Client Portal</span>
			<h1><?= e($user['company_name']) ?></h1>
			<p>
				Welcome, <?= e($user['contact_name']) ?>. Track your rental estate and support requests.
			</p>
		</div>
		<a class="btn outline" href="<?= url('portal-logout.php') ?>">Logout</a>
	</div>

	<div class="cards">
		<div class="stat">
			<b><?= count($assets) ?></b>
			<span>Assets</span>
		</div>
		<div class="stat">
			<b><?= count(array_filter($assets, fn($asset) => $asset['status'] === 'deployed')) ?></b>
			<span>Deployed</span>
		</div>
		<div class="stat">
			<b><?= count($tickets) ?></b>
			<span>Recent Tickets</span>
		</div>
	</div>

	<div class="panel">
		<div class="section-head">
			<h2>Asset Dashboard</h2>
			<a class="btn small" href="<?= url('helpdesk.php') ?>">Raise a Ticket</a>
		</div>

		<div class="table-wrap">
			<table>
				<thead>
					<tr>
						<th>Asset</th>
						<th>Device</th>
						<th>Holder</th>
						<th>Location</th>
						<th>Rental End</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($assets as $asset): ?>
						<tr>
							<td><?= e($asset['asset_tag']) ?></td>
							<td>
								<?= e($asset['device_name']) ?><br>
								<small><?= e($asset['configuration']) ?></small>
							</td>
							<td><?= e($asset['holder_name']) ?></td>
							<td><?= e($asset['location']) ?></td>
							<td><?= e($asset['rental_end']) ?></td>
							<td><?= e(ucwords(str_replace('_', ' ', $asset['status']))) ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<div class="panel">
		<div class="section-head">
			<h2>Support Tickets</h2>
			<a href="<?= url('helpdesk-status.php') ?>">View status page</a>
		</div>

		<?php if (!$tickets): ?>
			<p>No tickets yet.</p>
		<?php else: ?>
			<div class="table-wrap">
				<table>
					<thead>
						<tr>
							<th>#</th>
							<th>Subject</th>
							<th>Priority</th>
							<th>Status</th>
							<th>Updated</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($tickets as $ticket): ?>
							<tr>
								<td><?= e($ticket['id']) ?></td>
								<td><?= e($ticket['subject']) ?></td>
								<td><?= e(ucfirst($ticket['priority'])) ?></td>
								<td><?= e(ucwords(str_replace('_', ' ', $ticket['status']))) ?></td>
								<td><?= e($ticket['updated_at']) ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
