function toggleCompany(form) {
    const business = form.querySelector(
        'input[name="segment"]:checked'
    )?.value === 'business';

    const companyField = form.querySelector('#companyField');

    if (companyField) {
        companyField.style.display = business ? 'block' : 'none';
    }

    const quantity = form.querySelector('input[name="quantity"]');

    if (quantity) {
        quantity.min = business ? '5' : '1';
    }
}

function validateEnquiry(form) {
    if (form.website && form.website.value) {
        return false;
    }

    const devices = form.querySelectorAll(
        'input[name="devices[]"]:checked'
    );

    if (!devices.length) {
        alert('Please select at least one device type.');
        return false;
    }

    const segment = form.querySelector(
        'input[name="segment"]:checked'
    )?.value;

    if (
        segment === 'business' &&
        Number(form.quantity.value) < 5
    ) {
        alert('Business enquiries are intended for 5+ devices.');
        return false;
    }

    return true;
}

function setupFadeIn() {
    const elements = document.querySelectorAll(
        '[data-fade], .fade-in'
    );

    if (!elements.length) {
        return;
    }

    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        },
        {
            threshold: 0.12,
        }
    );

    elements.forEach((element) => observer.observe(element));
}

document.addEventListener('DOMContentLoaded', () => {
    document
        .querySelectorAll('.enquiry-form')
        .forEach((form) => {
            toggleCompany(form);

            form
                .querySelectorAll('input[name="segment"]')
                .forEach((radio) => {
                    radio.addEventListener(
                        'change',
                        () => toggleCompany(form)
                    );
                });
        });

    document
        .querySelectorAll('[data-track]')
        .forEach((element) => {
            element.addEventListener('click', () => {
                const type = element.dataset.track;
                const base = window.NEXTSTEP_BASE || '';

                fetch(
                    `${base}/actions/track.php?type=${encodeURIComponent(type)}&source=click`,
                    {
                        keepalive: true,
                    }
                ).catch(() => {});
            });
        });

    const modal = document.getElementById('exitModal');

    if (
        modal &&
        !sessionStorage.getItem('exitShown')
    ) {
        document.addEventListener('mouseleave', (event) => {
            if (event.clientY < 10) {
                modal.classList.add('show');
                sessionStorage.setItem('exitShown', '1');
            }
        });
    }

    document
        .querySelectorAll('.modal-close')
        .forEach((button) => {
            button.onclick = () => {
                button
                    .closest('.modal')
                    ?.classList.remove('show');
            };
        });

    setupFadeIn();
});
