CREATE DATABASE IF NOT EXISTS nextstep CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nextstep;
CREATE TABLE admins(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(190) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE devices(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(190) NOT NULL,category VARCHAR(100) NOT NULL,brand VARCHAR(100) DEFAULT '',specs TEXT NOT NULL,use_case VARCHAR(255) DEFAULT '',price DECIMAL(10,2) NULL,image VARCHAR(500) DEFAULT '',accessories TEXT DEFAULT '',status ENUM('active','inactive') DEFAULT 'active',featured TINYINT(1) DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX(category),INDEX(brand));
CREATE TABLE enquiries(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,segment ENUM('business','individual') NOT NULL,name VARCHAR(150) NOT NULL,company VARCHAR(190) DEFAULT '',email VARCHAR(190) NOT NULL,phone VARCHAR(20) NOT NULL,city VARCHAR(150) NOT NULL,devices TEXT NOT NULL,quantity INT NOT NULL,duration VARCHAR(50) NOT NULL,requirements TEXT,message TEXT,start_date DATE NULL,source VARCHAR(100) DEFAULT 'website',status ENUM('new','contacted','qualified','quoted','won','lost') DEFAULT 'new',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX(created_at),INDEX(segment),INDEX(status));
CREATE TABLE callbacks(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,phone VARCHAR(20) NOT NULL,preferred_time VARCHAR(80) NOT NULL,source VARCHAR(100) DEFAULT 'website',status ENUM('new','called','closed') DEFAULT 'new',created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE leads_events(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,event_type VARCHAR(50) NOT NULL,source VARCHAR(100) DEFAULT '',page_url VARCHAR(500) DEFAULT '',ip_hash VARCHAR(128) DEFAULT '',user_agent VARCHAR(500) DEFAULT '',created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX(event_type),INDEX(created_at));
CREATE TABLE newsletters(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,email VARCHAR(190) UNIQUE NOT NULL,source VARCHAR(100) DEFAULT 'resources',created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE industries(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,challenge TEXT NOT NULL,what_we_provide TEXT NOT NULL,recommended_devices TEXT NOT NULL,outcome TEXT NOT NULL,sort_order INT DEFAULT 1,status ENUM('active','inactive') DEFAULT 'active');
CREATE TABLE testimonials(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,designation VARCHAR(150) DEFAULT '',company VARCHAR(190) DEFAULT '',city VARCHAR(100) DEFAULT '',quote TEXT NOT NULL,logo VARCHAR(500) DEFAULT '',status ENUM('active','inactive') DEFAULT 'active');
CREATE TABLE clients(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,logo VARCHAR(500) DEFAULT '',status ENUM('active','inactive') DEFAULT 'active',sort_order INT DEFAULT 1);
CREATE TABLE posts(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(255) NOT NULL,slug VARCHAR(255) UNIQUE NOT NULL,category VARCHAR(120) NOT NULL,excerpt TEXT,content LONGTEXT NOT NULL,cover_image VARCHAR(500) DEFAULT '',read_time VARCHAR(50) DEFAULT '5 min read',meta_title VARCHAR(255) DEFAULT '',meta_description VARCHAR(255) DEFAULT '',status ENUM('draft','published') DEFAULT 'draft',published_at DATETIME NULL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,INDEX(category),INDEX(status));
CREATE TABLE settings(setting_key VARCHAR(100) PRIMARY KEY,setting_value TEXT NOT NULL);
INSERT INTO admins(name,email,password) VALUES('Administrator','admin@nextsteppune.com','$2y$10$92F7j3wQ0H6lX6xvP4l7jO5s9zvV5tK0V5Y2w1vYwVqQ5zj7oZq8u');
INSERT INTO settings VALUES
('sales_email','sales@nextsteppune.com'),('support_email','support@nextsteppune.com'),('business_hours','Monday to Saturday, 10:00 AM to 7:00 PM IST'),('gstin','[confirm]'),('registration_no','[confirm]'),('devices_deployed','5,000+'),('clients_count','[confirm]'),('cities_covered','50+'),('uptime','[confirm]'),('years_operation','[confirm]'),('replacement_hours','[confirm]'),('whatsapp_response_minutes','[confirm]'),('support_ticket_hours','[confirm]'),('bulk_quote_days','[confirm]'),('standard_build_days','[confirm]'),('founding_year','[confirm]'),('buyout_policy','[confirm policy]'),('google_rating','[confirm]'),('google_review_count','[confirm]'),('google_maps_url','https://maps.google.com/'),('linkedin',''),('instagram',''),('facebook',''),('youtube','');
INSERT INTO devices(name,category,brand,specs,use_case,price,accessories,featured) VALUES
('Business Laptop – Core i5','Laptop','Dell / HP / Lenovo','Intel Core i5 / Ryzen 5, 8–16 GB RAM, 512 GB SSD','Sales, operations, support, admin and general office use',NULL,'Charger, bag',1),
('Performance Laptop – Core i7','Laptop','Dell / HP / Lenovo / ASUS','Intel Core i7 / Ryzen 7, 16–32 GB RAM, dedicated graphics','Developers, analysts, consultants and hybrid teams',NULL,'Charger, bag, optional dock',1),
('Business Desktop','Desktop','Dell / HP / Lenovo','Intel Core i3 to i7, 8–16 GB RAM, SSD, monitor and peripherals','BPO floors, data entry, training labs, fixed workstations',NULL,'Keyboard, mouse, monitor',1),
('Custom Assembled Desktop','Assembled Desktop','Custom','Configured to specification — CPU, GPU, RAM and storage to order','Cost-optimised bulk deployments and specialised workloads',NULL,'Keyboard, mouse, monitor on request',0),
('MacBook Air / Pro','MacBook','Apple','MacBook Air and MacBook Pro, M-series processors','Designers, video editors, iOS developers, leadership teams',NULL,'Charger, bag, optional dock',1),
('High Performance Workstation','Workstation','Dell / HP / Lenovo / Custom','Xeon / Core i9, 32–128 GB RAM, RTX professional graphics','CAD, 3D rendering, VFX, simulation and AI workloads',NULL,'Keyboard, mouse, monitor on request',1),
('Gaming PC','Gaming PC','ASUS / Acer / MSI / Custom','High-refresh gaming configuration with configurable GPU/RAM','Individual rentals in Pune, events, gaming zones and lounges',NULL,'Gaming peripherals on request',0),
('PlayStation 5 / 4','Console','Sony','PlayStation 5 / PlayStation 4 with required accessories','Pune individual rentals, events and gaming',NULL,'Controller, power and HDMI',0);
INSERT INTO industries(name,challenge,what_we_provide,recommended_devices,outcome,sort_order) VALUES
('IT & Software','Development, QA and delivery teams scale with project cycles. Procurement cannot keep pace.','Performance laptops and desktops, standard images, VPN/security, MDM and multi-city delivery.','Core i5/i7 and Ryzen 5/7 laptops with 16–32 GB RAM; MacBooks; workstations.','New engineers are productive on day one and hardware cost tracks project revenue.',1),
('Startups','Capital is better spent on product, hiring and go-to-market than depreciating hardware.','Fast-turnaround rentals, month-on-month scalability, preconfigured devices and one point of contact.','Business/performance laptops, MacBooks and assembled desktops.','A full IT setup without an IT department.',2),
('BPO / KPO','High-density floors, multi-shift usage and rapid ramp-ups make downtime measurable revenue loss.','Bulk desktops, staged rollouts, standby buffer devices, on-site engineers and asset reconciliation.','Desktops, assembled desktops with dual-monitor support and entry laptops.','Floors go live on schedule and failed seats are replaced quickly.',3),
('Education & Training','Computer labs, certification batches and skilling programmes need many machines for a defined period.','Batch rentals, uniform imaging, course software, restricted profiles and installation.','Desktops, assembled desktops and business laptops.','Fully equipped labs for the programme duration.',4),
('Media & Design','Editing, animation, VFX and design workloads demand high-end graphics and colour-accurate displays.','MacBooks and Windows workstations with professional GPUs, software and high-capacity SSDs.','MacBook Pro M-series; RTX workstations with 32–128 GB RAM.','Creative teams work on current-generation hardware.',5),
('Engineering & Manufacturing','CAD, CAM, simulation and PLM workloads require certified workstations at plant locations.','Certified workstations, plant-site delivery, installation and local vendor support.','Xeon/Core i9 workstations; performance laptops.','Teams get certified hardware without repeated capital approval.',6),
('Events & Corporate Training','Conferences, exhibitions, hackathons, assessments and training need many devices for days or weeks.','Short-term bulk rentals, uniform imaging, on-site setup, standby support and collection.','Laptops, desktops, gaming PCs and consoles.','Predictable single-invoice event IT setup.',7),
('Remote & Distributed Teams','Employees are hired in cities with no office or IT presence.','Direct-to-employee delivery, remote onboarding, MDM, support and recovery.','Business/performance laptops with standard corporate image.','Remote joiners are equipped on day one.',8);
INSERT INTO testimonials(name,designation,company,city,quote) VALUES
('Approved Client 1','IT Manager','Client Company','India','We onboarded 40 engineers in three cities with devices delivered imaged and MDM-enrolled.'),
('Approved Client 2','Head of Operations','Client Company','India','Moving to a rental model freed capital and made our asset records much easier to manage.'),
('Approved Client 3','Freelance Designer','Independent','Pune','I rented a MacBook for a project and received fast delivery and responsive support.');
INSERT INTO clients(name,sort_order) VALUES('Client Logo 1',1),('Client Logo 2',2),('Client Logo 3',3),('Client Logo 4',4),('Client Logo 5',5),('Client Logo 6',6),('Client Logo 7',7),('Client Logo 8',8);
INSERT INTO posts(title,slug,category,excerpt,content,read_time,meta_title,meta_description,status,published_at) VALUES
('What Is Device-as-a-Service (DaaS) and Why Indian Companies Are Adopting It','what-is-device-as-a-service-daas-india','Device-as-a-Service (DaaS)','Understand the DaaS model and how it changes the economics and operational workload of IT hardware.','<h2>What is DaaS?</h2><p>Device-as-a-Service combines hardware rental with configuration, deployment, support and asset visibility. Instead of buying every device, organisations pay a predictable operating expense.</p><h2>Why teams consider it</h2><ul><li>Reduce upfront capital investment.</li><li>Standardise configuration before dispatch.</li><li>Scale devices with hiring and project cycles.</li><li>Centralise support and asset visibility.</li></ul><p>For a business evaluating laptop rental for companies in India, the key question is not only monthly price; it is the operational cost of procurement, deployment, support and recovery.</p>','6 min read','What Is DaaS? | Device-as-a-Service India','Learn what Device-as-a-Service means and why Indian companies use rental hardware with deployment, support and asset visibility.','published',NOW()),
('OPEX vs CAPEX: The Real Cost of Buying Laptops for Your Team','opex-vs-capex-it-hardware','IT Cost & OPEX vs CAPEX','A practical framework for comparing ownership with a managed rental model.','<h2>Compare the whole lifecycle</h2><p>CAPEX is more than the purchase invoice. Procurement, configuration, support, refresh cycles and asset recovery all create operational work.</p><p>A rental model moves hardware into a predictable monthly OPEX line while bundling operational services.</p>','5 min read','OPEX vs CAPEX IT Hardware | Next Step','Compare the operational and financial considerations of buying laptops versus renting them for a team.','published',NOW()),
('Laptop on Rent in Pune: Plans, Documents and Delivery Explained','laptop-on-rent-pune-plans-documents-delivery','Gaming & Personal Rentals (Pune)','What Pune customers should know about monthly rentals, documents, delivery and pickup.','<h2>Flexible monthly rentals in Pune</h2><p>Individuals in Pune and PCMC can rent laptops, MacBooks, gaming PCs and PlayStation consoles. Delivery and pickup are included.</p><h2>Documents</h2><p>Individuals require government-issued ID, address proof and a security deposit, subject to the agreed rental terms.</p>','5 min read','Laptop on Rent in Pune | Plans & Documents','Learn about laptop rental in Pune, documents, delivery, pickup and flexible monthly rental plans.','published',NOW());

-- ============================================================
-- PHASE 2 + PHASE 3 EXTENSIONS
-- ============================================================
CREATE TABLE portal_users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 company_name VARCHAR(190) NOT NULL,
 contact_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) UNIQUE NOT NULL,
 phone VARCHAR(30) DEFAULT '',
 password VARCHAR(255) NOT NULL,
 status ENUM('active','inactive') DEFAULT 'active',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE assets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 portal_user_id BIGINT UNSIGNED NOT NULL,
 asset_tag VARCHAR(100) UNIQUE NOT NULL,
 device_name VARCHAR(190) NOT NULL,
 serial_number VARCHAR(190) DEFAULT '',
 category VARCHAR(100) DEFAULT '',
 brand VARCHAR(100) DEFAULT '',
 configuration TEXT,
 holder_name VARCHAR(150) DEFAULT '',
 location VARCHAR(150) DEFAULT '',
 rental_start DATE NULL,
 rental_end DATE NULL,
 status ENUM('deployed','available','repair','returned') DEFAULT 'deployed',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(portal_user_id) REFERENCES portal_users(id) ON DELETE CASCADE,
 INDEX(portal_user_id), INDEX(status)
);
CREATE TABLE tickets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 portal_user_id BIGINT UNSIGNED NOT NULL,
 asset_id BIGINT UNSIGNED NULL,
 subject VARCHAR(255) NOT NULL,
 description TEXT NOT NULL,
 priority ENUM('low','medium','high','critical') DEFAULT 'medium',
 status ENUM('open','in_progress','waiting_customer','resolved','closed') DEFAULT 'open',
 assigned_to VARCHAR(150) DEFAULT '',
 resolution TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(portal_user_id) REFERENCES portal_users(id) ON DELETE CASCADE,
 FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL,
 INDEX(portal_user_id), INDEX(status)
);
CREATE TABLE ticket_replies (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ticket_id BIGINT UNSIGNED NOT NULL,
 portal_user_id BIGINT UNSIGNED NULL,
 admin_id INT UNSIGNED NULL,
 message TEXT NOT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
 INDEX(ticket_id)
);
CREATE TABLE cities (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 slug VARCHAR(120) UNIQUE NOT NULL,
 region VARCHAR(150) DEFAULT '',
 headline VARCHAR(255) NOT NULL,
 intro TEXT NOT NULL,
 coverage TEXT NOT NULL,
 devices TEXT NOT NULL,
 support TEXT NOT NULL,
 meta_title VARCHAR(255) DEFAULT '',
 meta_description VARCHAR(255) DEFAULT '',
 status ENUM('active','inactive') DEFAULT 'active',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE calculator_prices (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 device_type VARCHAR(100) UNIQUE NOT NULL,
 monthly_price DECIMAL(10,2) NOT NULL,
 minimum_months INT DEFAULT 1,
 active TINYINT(1) DEFAULT 1
);
CREATE TABLE calculator_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(30) NOT NULL,
 city VARCHAR(150) NOT NULL,
 device_type VARCHAR(100) NOT NULL,
 quantity INT NOT NULL,
 duration INT NOT NULL,
 estimated_monthly DECIMAL(12,2) NOT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE chat_messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 session_id VARCHAR(100) NOT NULL,
 visitor_name VARCHAR(150) DEFAULT '',
 visitor_email VARCHAR(190) DEFAULT '',
 message TEXT NOT NULL,
 reply TEXT DEFAULT '',
 channel ENUM('website','whatsapp') DEFAULT 'website',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 INDEX(session_id)
);
CREATE TABLE profile_downloads (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 company VARCHAR(190) DEFAULT '',
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(30) DEFAULT '',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO portal_users(company_name,contact_name,email,phone,password) VALUES('Demo Enterprise Pvt Ltd','Demo Client','client@example.com','9999999999','$2y$12$zFz0Pbf7EwbQcqmYC6VNyu4vHWuMaD40MGEFeaYsd5ep2glRfqRPe');
INSERT INTO assets(portal_user_id,asset_tag,device_name,serial_number,category,brand,configuration,holder_name,location,rental_start,rental_end,status) VALUES
(1,'NS-DEMO-001','Business Laptop – Core i5','DEMO-SN-001','Laptop','Dell','Core i5, 16 GB RAM, 512 GB SSD','Demo Employee','Pune','2026-01-01','2026-12-31','deployed'),
(1,'NS-DEMO-002','Performance Laptop – Core i7','DEMO-SN-002','Laptop','Lenovo','Core i7, 32 GB RAM, 1 TB SSD','Demo Employee 2','Mumbai','2026-02-01','2027-01-31','deployed');
INSERT INTO cities(name,slug,region,headline,intro,coverage,devices,support,meta_title,meta_description) VALUES
('Pune','pune','Maharashtra','Laptop, Desktop and Workstation Rental in Pune','Next Step provides business device rentals across Pune and PCMC, plus flexible personal rentals for laptops, MacBooks, gaming PCs and PlayStation consoles.','Pune city and PCMC with delivery, pickup, configuration and support.','Laptops, desktops, MacBooks, workstations, gaming PCs, PS5 and PS4.','Business deployments include managed support; individual rentals include delivery and pickup within Pune/PCMC.','Laptop & Desktop Rental in Pune | Next Step','Rent laptops, desktops, MacBooks and gaming devices in Pune with delivery, pickup and support.'),
('Mumbai','mumbai','Maharashtra','Business Laptop and Desktop Rental in Mumbai','Deploy configured laptops, desktops and workstations for teams in Mumbai through a nationwide DaaS model.','Mumbai and surrounding business locations through coordinated delivery and partner support.','Business laptops, desktops, MacBooks, workstations and assembled desktops.','Preconfigured deployment, delivery, pickup, remote support and local partner support.','Laptop Rental for Companies in Mumbai | Next Step','Business laptop, desktop and workstation rental in Mumbai with configured deployment and support.'),
('Bengaluru','bengaluru','Karnataka','Device-as-a-Service and Laptop Rental in Bengaluru','Equip software, engineering and startup teams in Bengaluru without tying up capital in hardware.','Bengaluru and distributed teams through nationwide delivery.','Performance laptops, MacBooks, desktops and workstations.','MDM-ready configuration, remote support, delivery, pickup and replacement coordination.','Laptop Rental for Companies in Bengaluru | Next Step','Rent configured business laptops and workstations in Bengaluru with DaaS support.'),
('Hyderabad','hyderabad','Telangana','Business Device Rental in Hyderabad','Next Step supports Hyderabad teams with flexible device rental, configuration and lifecycle support.','Hyderabad and multi-city deployments across India.','Laptops, desktops, MacBooks and workstations.','Preconfiguration, delivery, pickup, remote support and on-site partner coordination.','Laptop Rental for Companies in Hyderabad | Next Step','Business device rental in Hyderabad with deployment, support and asset visibility.'),
('Delhi NCR','delhi-ncr','Delhi NCR','Laptop, Desktop and Workstation Rental in Delhi NCR','Support distributed and high-volume teams across Delhi NCR with rental hardware and managed deployment.','Delhi NCR and multi-city enterprise deployments.','Business laptops, desktops, MacBooks and workstations.','Bulk rollout, asset reconciliation, support and replacement coordination.','Laptop Rental for Companies in Delhi NCR | Next Step','Rent business laptops, desktops and workstations in Delhi NCR with nationwide DaaS support.'),
('Chennai','chennai','Tamil Nadu','Business Laptop and Desktop Rental in Chennai','Flexible device rental for engineering, BPO, software and distributed teams in Chennai.','Chennai and nationwide enterprise locations.','Laptops, desktops, workstations and MacBooks.','Configured deployment, delivery, pickup, remote support and partner network.','Laptop Rental for Companies in Chennai | Next Step','Business laptop and desktop rental in Chennai with deployment and support.');
INSERT INTO calculator_prices(device_type,monthly_price,minimum_months) VALUES
('Business Laptop – Core i5',1800,1),('Performance Laptop – Core i7',3200,3),('Business Desktop',1500,3),('Custom Assembled Desktop',2500,3),('MacBook Air / Pro',4500,1),('High Performance Workstation',8500,3),('Gaming PC',4000,1),('PlayStation 5 / 4',2500,1);
INSERT INTO settings(setting_key,setting_value) VALUES
('asset_portal_url','portal-login.php'),('helpdesk_url','helpdesk.php'),('helpdesk_status_url','helpdesk-status.php'),('live_chat_enabled','1'),('company_profile_title','Next Step — Device-as-a-Service Company Profile'),('calculator_enabled','1'),('city_pages_enabled','1'),('profile_gate_enabled','1')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

-- ============================================================
-- BLACK / WHITE THEME DEVICE IMAGE ASSIGNMENTS
-- ============================================================
UPDATE devices SET image = 'assets/images/devices/work-laptop.jpg'
WHERE name = 'Business Laptop – Core i5';

UPDATE devices SET image = 'assets/images/devices/gaming-laptop.jpg'
WHERE name = 'Performance Laptop – Core i7';

UPDATE devices SET image = 'assets/images/devices/desktop.jpg'
WHERE name = 'Business Desktop';

UPDATE devices SET image = 'assets/images/devices/assembled-desktop.jpg'
WHERE name = 'Custom Assembled Desktop';

UPDATE devices SET image = 'assets/images/devices/macbook.jpg'
WHERE name = 'MacBook Air / Pro';

UPDATE devices SET image = 'assets/images/devices/workstation.jpg'
WHERE name = 'High Performance Workstation';

UPDATE devices SET image = 'assets/images/devices/gaming-pc.jpg'
WHERE name = 'Gaming PC';

UPDATE devices SET image = 'assets/images/devices/console.jpg'
WHERE name = 'PlayStation 5 / 4';
