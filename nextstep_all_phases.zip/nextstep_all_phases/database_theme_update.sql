USE nextstep;

UPDATE devices SET image = 'assets/images/devices/work-laptop.jpg'
WHERE name = 'Business Laptop – Core i5';

UPDATE devices SET image = 'assets/images/devices/gaming-laptop.jpg'
WHERE name = 'Performance Laptop – Core i7';

UPDATE devices SET image = 'assets/images/devices/desktop.jpg'
WHERE name = 'Business Desktop';

UPDATE devices SET image = 'assets/images/devices/assembled-desktop.jpg'
WHERE name = 'Custom Assembled Desktop';

UPDATE devices SET image = 'assets/images/devices/macbook.jpg'
WHERE name = 'MacBook Air / Pro';

UPDATE devices SET image = 'assets/images/devices/workstation.jpg'
WHERE name = 'High Performance Workstation';

UPDATE devices SET image = 'assets/images/devices/gaming-pc.jpg'
WHERE name = 'Gaming PC';

UPDATE devices SET image = 'assets/images/devices/console.jpg'
WHERE name = 'PlayStation 5 / 4';
