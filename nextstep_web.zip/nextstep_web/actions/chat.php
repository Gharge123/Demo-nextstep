<?php

require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');


/*
|--------------------------------------------------------------------------
| Only POST allowed
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    json_response([
        'ok' => false,
        'message' => 'Invalid request method. Please use POST.'
    ], 405);
}


/*
|--------------------------------------------------------------------------
| Read POST data
|--------------------------------------------------------------------------
*/

$action = trim($_POST['action'] ?? '');

$message = trim($_POST['message'] ?? '');

$name = trim($_POST['name'] ?? '');

$email = trim($_POST['email'] ?? '');

$sessionId = trim($_POST['session_id'] ?? '');


/*
|--------------------------------------------------------------------------
| IMPORTANT
|
| If frontend does not send action, but message exists,
| automatically treat this as send.
|--------------------------------------------------------------------------
*/

if ($action === '') {

    if ($message !== '') {

        $action = 'send';

    } else {

        json_response([
            'ok' => false,
            'message' => 'Message is required.'
        ], 422);
    }
}


/*
|--------------------------------------------------------------------------
| Check action
|--------------------------------------------------------------------------
*/

if ($action !== 'send') {

    json_response([
        'ok' => false,
        'message' => 'Invalid chat action.'
    ], 400);
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    json_response([
        'ok' => false,
        'message' => 'Security verification failed. Please refresh the page and try again.'
    ], 419);
}


/*
|--------------------------------------------------------------------------
| Validate message
|--------------------------------------------------------------------------
*/

if ($message === '') {

    json_response([
        'ok' => false,
        'message' => 'Please enter a message.'
    ], 422);
}


/*
|--------------------------------------------------------------------------
| Session ID
|--------------------------------------------------------------------------
*/

if ($sessionId === '') {

    $sessionId = bin2hex(
        random_bytes(16)
    );
}

$sessionId = substr(
    $sessionId,
    0,
    100
);


/*
|--------------------------------------------------------------------------
| Validate email
|--------------------------------------------------------------------------
*/

if (
    $email !== '' &&
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    json_response([
        'ok' => false,
        'message' => 'Please enter a valid email address.'
    ], 422);
}


/*
|--------------------------------------------------------------------------
| Automatic reply
|--------------------------------------------------------------------------
*/

$reply =
    'Thanks for contacting Next Step. ' .
    'For pricing, cities served or device availability, ' .
    'you can continue on WhatsApp and our team can assist you.';


/*
|--------------------------------------------------------------------------
| Save chat message
|--------------------------------------------------------------------------
*/

try {

    $pdo = db();

    $sql = "
        INSERT INTO chat_messages
        (
            session_id,
            visitor_name,
            visitor_email,
            message,
            reply
        )
        VALUES
        (
            :session_id,
            :visitor_name,
            :visitor_email,
            :message,
            :reply
        )
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':session_id' =>
            $sessionId,

        ':visitor_name' =>
            $name,

        ':visitor_email' =>
            $email,

        ':message' =>
            $message,

        ':reply' =>
            $reply
    ]);


} catch (PDOException $e) {

    error_log(
        'CHAT DATABASE ERROR: ' .
        $e->getMessage()
    );

    json_response([
        'ok' => false,
        'message' =>
            'Unable to save your message. Please try again.'
    ], 500);
}


/*
|--------------------------------------------------------------------------
| Event logging
|--------------------------------------------------------------------------
*/

try {

    log_event(
        'live_chat',
        'website'
    );

} catch (Throwable $e) {

    error_log(
        'CHAT LOG ERROR: ' .
        $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| WhatsApp
|--------------------------------------------------------------------------
*/

$whatsappMessage =
    'Hi Next Step, I started a website chat and need help with: ' .
    $message;

$whatsapp = whatsapp_url(
    $whatsappMessage
);


/*
|--------------------------------------------------------------------------
| SUCCESS
|--------------------------------------------------------------------------
*/

json_response([
    'ok' => true,
    'message' => 'Message sent successfully.',
    'reply' => $reply,
    'session_id' => $sessionId,
    'whatsapp' => $whatsapp
], 200);