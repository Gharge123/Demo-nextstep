# Next Step — Core PHP + MySQL — All Phases

This package implements the website requirements from **Next-Step-Website-Content-and-Launch-Plan.pdf** using **Core PHP + MySQL** instead of WordPress.

## Included scope

### Phase 1 — Launch
- Home, Industries, About, Contact, Resources/Blog
- Device catalog with type/brand/use-case filters and enquiry action
- Business and Individual rental enquiry flows
- Conditional enterprise/individual fields and validation
- Spam protection / CSRF / honeypot
- Email notification + customer acknowledgement
- Optional CRM/Google Apps Script webhook
- WhatsApp click-to-chat and event tracking
- Click-to-call and call-source tracking
- Mobile-first responsive UI and sticky contact bar
- Blog CMS with categories, drafts/publishing and SEO fields
- SEO metadata, canonical URLs, schema, robots.txt and sitemap
- FAQ, trust signals, client logos and testimonials management

### Phase 2 — Post-launch
- Client Asset Portal login
- Client asset dashboard
- Asset records: tag, serial, holder, location, configuration, rental dates and status
- Helpdesk ticket creation and ticket status workflow
- Helpdesk status/explainer page
- Live website chat with FAQ-style response and WhatsApp handoff
- Gated downloadable company profile PDF
- Admin management for portal users, assets, tickets, chat conversations and profile leads

### Phase 3 — Growth
- Interactive rental cost calculator: device × quantity × duration
- Indicative monthly and term estimate
- Calculator lead capture + optional CRM webhook
- Admin-maintainable calculator pricing
- Programmatic city landing pages
- Pune, Mumbai, Bengaluru, Hyderabad, Delhi NCR and Chennai pages
- City index and XML sitemap inclusion

## Installation

1. Copy the project to XAMPP `htdocs`, for example:
   `C:/xampp/htdocs/nextstep/`
2. Create/import the MySQL database using `database.sql`.
3. Edit `config/config.php`:
   - DB_HOST
   - DB_NAME
   - DB_USER
   - DB_PASS
   - BASE_URL
   - SITE_URL
   - WhatsApp/phone/email
   - GA4/GTM IDs if available
   - CRM webhook if used
4. Ensure PHP has PDO MySQL and cURL enabled.
5. Open `/create_admin_password.php` once if you need to set an admin password, then delete/disable that file.
6. Admin: `/admin/login.php`
7. Client portal demo: `/portal-login.php`
   - Email: `client@example.com`
   - Password: `Client@123`
8. Change the demo client password immediately for any real deployment.

## Important client configuration

The source document marks several values as `[confirm]`. Replace them in Admin > Settings before launch. Do not publish unverified SLA, customer, review, GSTIN, coverage or performance claims.

The sample calculator prices and demo portal assets are placeholders for development. Final pricing and asset data must be supplied by the client.

## Key URLs

- `/`
- `/industries.php`
- `/about.php`
- `/devices.php`
- `/contact.php`
- `/resources.php`
- `/laptop-on-rent-pune.php`
- `/portal-login.php`
- `/portal.php`
- `/helpdesk.php`
- `/helpdesk-status.php`
- `/company-profile.php`
- `/rental-calculator.php`
- `/cities.php`
- `/city.php?slug=pune`
- `/sitemap.php`

## Security notes

Use HTTPS in production. Replace the sample credentials, configure mail delivery/SMTP, restrict admin access, use strong passwords, and review uploads and external integrations before go-live.
