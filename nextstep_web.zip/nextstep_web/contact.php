<?php require_once __DIR__.'/config/db.php';$metaTitle='Contact Next Step | Laptop on Rent in Pune & India';$metaDescription='Request a rental quote for laptops, desktops, MacBooks or consoles. Call, WhatsApp or send your requirement — response within one working day.';include __DIR__.'/includes/header.php';?>
<section class="page-hero">
    <div class="container">
        <span class="eyebrow">Contact Us</span>
        <h1>Let's Get Your Team Equipped</h1>
        <p>
            Share your requirement — device type, quantity, city and rental duration — and we will respond with a
            configuration recommendation and a quote within one working day.
        </p>
        <div class="actions">
            <a class="btn primary" href="#quote">Send Enquiry</a
            ><a class="btn white" href="<?=whatsapp_url()?>" data-track="whatsapp">Chat on WhatsApp</a
            ><a class="btn white" href="<?=track_url('call','contact')?>" data-track="call">Call Now</a>
        </div>
    </div>
</section>
<section class="section" id="quote">
    <div class="container contact-grid">
        <div class="form-card">
            <h2>Request a Rental Quote</h2>
            <p>The more detail you share, the more accurate your quote will be.</p>
            <?php if($f=get_flash()):?>
            <div class="alert <?=e($f['type'])?>"><?=e($f['message'])?></div>
            <?php endif;?><?php include __DIR__.'/includes/enquiry_form.php';?>
        </div>
        <aside class="contact-info">
            <h3>Support Channels</h3>
            <p>
                <b>Sales enquiries</b><br />New rentals, quotes and bulk requirements<br /><a
                    href="<?=track_url('call','contact-sales')?>"
                    data-track="call"
                    ><?=e(PHONE)?></a
                >
            </p>
            <p>
                <b>Existing client support</b><br />Device faults, replacements and escalations<br /><?=e(setting('support_email',SUPPORT_EMAIL))?>
            </p>
            <p>
                <b>WhatsApp</b><br />Quick questions, availability and Pune rentals<br /><a
                    href="<?=whatsapp_url()?>"
                    data-track="whatsapp"
                    >+91 79720 37331</a
                >
            </p>
            <h3>Response Commitment</h3>
            <ul>
                <li>Website enquiries: within one working day</li>
                <li>
                    WhatsApp during business hours: within <?=e(setting('whatsapp_response_minutes','[confirm]'))?>
                    minutes
                </li>
                <li>Support tickets: acknowledged within <?=e(setting('support_ticket_hours','[confirm]'))?> hours</li>
                <li>Bulk quote: within <?=e(setting('bulk_quote_days','[confirm]'))?> working days</li>
            </ul>
            <h3>Office & Coverage</h3>
            <p>
                Naveena Apartments, Telco–Bhosari Road, Trishul Sahakari Housing Society, Yashwantnagar, Pimpri Colony,
                Pimpri-Chinchwad, Maharashtra 411018
            </p>
            <p><b>Business:</b> Pan India<br /><b>Individual:</b> Pune and PCMC</p>
            <p><b>Business hours:</b> <?=e(setting('business_hours'))?></p>
            <a
                class="btn outline"
                href="<?=e(setting('google_maps_url','https://maps.google.com/'))?>"
                target="_blank"
                rel="noopener"
                >Open Google Map</a
            >
        </aside>
    </div>
</section>
<section class="section muted">
    <div class="container callback">
        <div>
            <span class="eyebrow">Prefer a call?</span>
            <h2>Request a Callback</h2>
            <p>Only name, number and preferred time are required.</p>
        </div>
        <form method="post" action="<?=url('actions/callback.php')?>">
            <input type="hidden" name="csrf" value="<?=csrf_token()?>" /><input
                class="honeypot"
                name="website"
                tabindex="-1"
            /><input name="name" placeholder="Name" required /><input
                name="phone"
                placeholder="10-digit phone"
                pattern="[0-9]{10}"
                maxlength="10"
                required
            /><select name="preferred_time" required>
                <option value="">Preferred time</option>
                <option>10 AM – 12 PM</option>
                <option>12 PM – 3 PM</option>
                <option>3 PM – 6 PM</option>
                <option>6 PM – 8 PM</option></select
            ><button class="btn primary">Request Callback</button>
        </form>
    </div>
</section>
<?php include __DIR__.'/includes/footer.php';?>
