<?php

require_once __DIR__ . '/config/db.php';

$metaTitle = 'Devices on Rent | Laptops, MacBooks, Desktops & Workstations | Next Step';

$metaDescription = 'Browse filterable laptops, desktops, MacBooks, workstations, gaming PCs and consoles with specifications and enquiry actions.';

// Get filters
$category = trim($_GET['category'] ?? '');
$brand    = trim($_GET['brand'] ?? '');
$use      = trim($_GET['use'] ?? '');

// --------------------------------------------------
// BUILD QUERY DYNAMICALLY
// --------------------------------------------------

$sql = "SELECT *
        FROM devices
        WHERE status = :status";

$params = [
    ':status' => 'active'
];

// Category filter
if ($category !== '') {
    $sql .= " AND category = :category";
    $params[':category'] = $category;
}

// Brand filter
if ($brand !== '') {
    $sql .= " AND brand LIKE :brand";
    $params[':brand'] = '%' . $brand . '%';
}

// Use-case filter
if ($use !== '') {
    $sql .= " AND use_case LIKE :use_case";
    $params[':use_case'] = '%' . $use . '%';
}

$sql .= " ORDER BY featured DESC, id DESC";

// Execute query
$s = db()->prepare($sql);
$s->execute($params);

$devices = $s->fetchAll(PDO::FETCH_ASSOC);


// --------------------------------------------------
// GET CATEGORIES
// --------------------------------------------------

$categoriesStmt = db()->query("
    SELECT DISTINCT category
    FROM devices
    WHERE status = 'active'
      AND category IS NOT NULL
      AND category <> ''
    ORDER BY category
");

$categories = $categoriesStmt->fetchAll(PDO::FETCH_COLUMN);


// --------------------------------------------------
// GET BRANDS
// --------------------------------------------------

$brandsStmt = db()->query("
    SELECT DISTINCT brand
    FROM devices
    WHERE status = 'active'
      AND brand IS NOT NULL
      AND brand <> ''
    ORDER BY brand
");

$brands = $brandsStmt->fetchAll(PDO::FETCH_COLUMN);


// --------------------------------------------------
// HEADER
// --------------------------------------------------

include __DIR__ . '/includes/header.php';

?>

<!-- PAGE HERO -->

<section class="page-hero">

    <div class="container">

        <span class="eyebrow">Device Catalog</span>

        <h1>
            Devices Built Around How Your Team Works
        </h1>

        <p>
            Filter by type and brand, review specifications and enquire
            for availability. Every device is supplied with required
            accessories; monitors, docks, headsets and webcams can be
            added on request.
        </p>

    </div>

</section>


<!-- DEVICE SECTION -->

<section class="section">

    <div class="container">

        <!-- FILTER FORM -->

        <form class="filter-form" method="get">

            <!-- CATEGORY -->

            <select name="category">

                <option value="">
                    All device types
                </option>

                <?php foreach ($categories as $c): ?>

                    <option
                        value="<?= e($c) ?>"
                        <?= $category === $c ? 'selected' : '' ?>
                    >
                        <?= e($c) ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <!-- BRAND -->

            <select name="brand">

                <option value="">
                    All brands
                </option>

                <?php foreach ($brands as $b): ?>

                    <option
                        value="<?= e($b) ?>"
                        <?= $brand === $b ? 'selected' : '' ?>
                    >
                        <?= e($b) ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <!-- USE CASE -->

            <input
                type="text"
                name="use"
                value="<?= e($use) ?>"
                placeholder="Use case e.g. CAD, gaming, BPO"
            >


            <!-- FILTER -->

            <button
                type="submit"
                class="btn primary"
            >
                Filter
            </button>


            <!-- RESET -->

            <a
                class="btn outline"
                href="<?= url('devices.php') ?>"
            >
                Reset
            </a>

        </form>


        <!-- RESULTS -->

        <?php if (empty($devices)): ?>

            <div class="empty-state">

                <h2>No devices found</h2>

                <p>
                    No devices match your selected filters.
                    Please try different filters.
                </p>

                <a
                    href="<?= url('devices.php') ?>"
                    class="btn primary"
                >
                    View All Devices
                </a>

            </div>

        <?php else: ?>

            <div class="device-grid">

                <?php foreach ($devices as $d): ?>

                    <article class="device-card">

                        <!-- IMAGE -->

                        <div class="device-image">

                            <?php if (!empty($d['image'])): ?>

                                <img
                                    src="<?= e($d['image']) ?>"
                                    alt="<?= e($d['name']) ?>"
                                    loading="lazy"
                                >

                            <?php else: ?>

                                <div class="placeholder">
                                    💻
                                </div>

                            <?php endif; ?>

                        </div>


                        <!-- DEVICE INFORMATION -->

                        <div>

                            <!-- CATEGORY -->

                            <?php if (!empty($d['category'])): ?>

                                <span class="tag">
                                    <?= e($d['category']) ?>
                                </span>

                            <?php endif; ?>


                            <!-- NAME -->

                            <h2>
                                <?= e($d['name']) ?>
                            </h2>


                            <!-- BRAND -->

                            <?php if (!empty($d['brand'])): ?>

                                <p>
                                    <b>Brand:</b>
                                    <?= e($d['brand']) ?>
                                </p>

                            <?php endif; ?>


                            <!-- SPECIFICATIONS -->

                            <?php if (!empty($d['specs'])): ?>

                                <p>
                                    <?= nl2br(e($d['specs'])) ?>
                                </p>

                            <?php endif; ?>


                            <!-- USE CASE -->

                            <?php if (!empty($d['use_case'])): ?>

                                <p>
                                    <b>Best suited for:</b>
                                    <?= e($d['use_case']) ?>
                                </p>

                            <?php endif; ?>


                            <!-- ACCESSORIES -->

                            <?php if (!empty($d['accessories'])): ?>

                                <p>
                                    <b>Accessories:</b>
                                    <?= e($d['accessories']) ?>
                                </p>

                            <?php endif; ?>


                            <!-- PRICE -->

                            <?php if (
                                isset($d['price']) &&
                                $d['price'] !== null &&
                                $d['price'] !== ''
                            ): ?>

                                <strong>
                                    ₹<?= e($d['price']) ?>/month
                                </strong>

                            <?php endif; ?>


                            <!-- ENQUIRE -->

                            <a
                                class="btn small primary"
                                href="<?= url(
                                    'contact.php?device=' .
                                    urlencode($d['name'])
                                ) ?>"
                            >
                                Enquire
                            </a>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

</section>


<?php

include __DIR__ . '/includes/footer.php';

?>