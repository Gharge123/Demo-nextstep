<?php require_once __DIR__.'/includes/functions.php';
if(client_logged_in()) redirect('portal.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$email=trim($_POST['email']??'');$password=$_POST['password']??'';$s=db()->prepare('SELECT * FROM portal_users WHERE email=? AND status="active" LIMIT 1');$s->execute([$email]);$u=$s->fetch();if($u&&password_verify($password,$u['password'])){session_regenerate_id(true);$_SESSION['portal_user_id']=$u['id'];redirect('portal.php');}$error='Invalid client login details.';}
$metaTitle='Client Asset Portal Login | Next Step'; include __DIR__.'/includes/header.php';?>
<div class="container section"><div class="form-card narrow"><span class="eyebrow">Client Portal</span><h1>Manage your rented assets</h1><p>View deployed devices, holders, locations, rental end dates and raise support tickets.</p><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button class="btn" type="submit">Sign In</button></form><small>Demo: client@example.com / Client@123</small></div></div>
<?php include __DIR__.'/includes/footer.php';?>
