<?php

require_once __DIR__ . '/config/db.php';

$metaTitle = 'DaaS & Device Rental Insights | Next Step Resources';

$metaDescription = 'Guides on device rental, DaaS, OPEX vs CAPEX, startup IT setup and remote workforce deployment from the Next Step team.';


// --------------------------------------------------
// GET CATEGORY FILTER
// --------------------------------------------------

$cat = trim($_GET['category'] ?? '');


// --------------------------------------------------
// GET POSTS
// --------------------------------------------------

// Start with the required condition
$sql = "
    SELECT *
    FROM posts
    WHERE status = :status
";

$params = [
    ':status' => 'published'
];


// Add category filter only when category is selected
if ($cat !== '') {

    $sql .= " AND category = :category";

    $params[':category'] = $cat;
}


// Sort latest published posts first
$sql .= "
    ORDER BY published_at DESC, id DESC
";


// Prepare and execute
$s = db()->prepare($sql);

$s->execute($params);

$posts = $s->fetchAll(PDO::FETCH_ASSOC);


// --------------------------------------------------
// GET AVAILABLE CATEGORIES
// --------------------------------------------------

$catsStmt = db()->query("
    SELECT DISTINCT category
    FROM posts
    WHERE status = 'published'
      AND category IS NOT NULL
      AND category <> ''
    ORDER BY category
");

$cats = $catsStmt->fetchAll(PDO::FETCH_COLUMN);


// --------------------------------------------------
// HEADER
// --------------------------------------------------

include __DIR__ . '/includes/header.php';

?>


<!-- ==========================================
     PAGE HERO
========================================== -->

<section class="page-hero">

    <div class="container">

        <span class="eyebrow">
            Resources / Blog
        </span>

        <h1>
            Resources on Device Rental,
            IT Deployment and the DaaS Model
        </h1>

        <p>
            Practical guidance for IT managers, founders and
            operations teams making hardware decisions —
            plus rental guides for individuals in Pune.
        </p>

    </div>

</section>


<!-- ==========================================
     BLOG SECTION
========================================== -->

<section class="section">

    <div class="container">

        <div class="blog-top">

            <div>

                <h2>
                    Featured & Latest
                </h2>

                <p>
                    Guides on DaaS, OPEX vs CAPEX, startup IT setup,
                    remote workforce deployment, device guides and
                    Pune-local rentals.
                </p>

            </div>


            <!-- CATEGORY FILTER -->

            <form
                method="get"
                class="blog-filter"
            >

                <select name="category">

                    <option value="">
                        All categories
                    </option>


                    <?php foreach ($cats as $c): ?>

                        <option
                            value="<?= e($c) ?>"
                            <?= $cat === $c ? 'selected' : '' ?>
                        >
                            <?= e($c) ?>
                        </option>

                    <?php endforeach; ?>

                </select>


                <button
                    type="submit"
                    class="btn outline"
                >
                    Filter
                </button>


                <?php if ($cat !== ''): ?>

                    <a
                        href="<?= url('resources.php') ?>"
                        class="btn outline"
                    >
                        Reset
                    </a>

                <?php endif; ?>

            </form>

        </div>


        <!-- ==========================================
             BLOG POSTS
        =========================================== -->

        <?php if (empty($posts)): ?>

            <div class="empty-state">

                <h2>
                    No articles found
                </h2>

                <p>
                    There are currently no published articles
                    in this category.
                </p>

                <a
                    href="<?= url('resources.php') ?>"
                    class="btn primary"
                >
                    View All Articles
                </a>

            </div>

        <?php else: ?>


            <div class="blog-grid">


                <?php foreach ($posts as $p): ?>

                    <article class="blog-card">


                        <!-- BLOG IMAGE -->

                        <div class="blog-image">

                            <?php if (!empty($p['cover_image'])): ?>

                                <img
                                    src="<?= e($p['cover_image']) ?>"
                                    alt="<?= e($p['title']) ?>"
                                    loading="lazy"
                                >

                            <?php else: ?>

                                <span>
                                    DaaS • Next Step
                                </span>

                            <?php endif; ?>

                        </div>


                        <!-- BLOG CONTENT -->

                        <div>


                            <!-- CATEGORY -->

                            <?php if (!empty($p['category'])): ?>

                                <span class="tag">
                                    <?= e($p['category']) ?>
                                </span>

                            <?php endif; ?>


                            <!-- TITLE -->

                            <h2>
                                <?= e($p['title']) ?>
                            </h2>


                            <!-- EXCERPT -->

                            <?php if (!empty($p['excerpt'])): ?>

                                <p>
                                    <?= e($p['excerpt']) ?>
                                </p>

                            <?php endif; ?>


                            <!-- META -->

                            <small>

                                <?php if (!empty($p['read_time'])): ?>

                                    <?= e($p['read_time']) ?>

                                <?php endif; ?>


                                <?php if (
                                    !empty($p['read_time']) &&
                                    !empty($p['published_at'])
                                ): ?>

                                    ·

                                <?php endif; ?>


                                <?php if (!empty($p['published_at'])): ?>

                                    <?= e(
                                        date(
                                            'd M Y',
                                            strtotime($p['published_at'])
                                        )
                                    ) ?>

                                <?php endif; ?>

                            </small>


                            <!-- READ ARTICLE -->

                            <a
                                href="<?= url(
                                    'post.php?slug=' .
                                    urlencode($p['slug'])
                                ) ?>"
                            >
                                Read article →
                            </a>


                        </div>

                    </article>

                <?php endforeach; ?>


            </div>

        <?php endif; ?>


    </div>

</section>


<!-- ==========================================
     NEWSLETTER
========================================== -->

<section class="section muted">

    <div class="container newsletter">


        <div>

            <span class="eyebrow">
                Stay informed
            </span>

            <h2>
                Subscribe for Updates
            </h2>

            <p>
                Get practical device rental and IT deployment
                guidance.
            </p>

        </div>


        <!-- NEWSLETTER FORM -->

        <form
            method="post"
            action="<?= url('actions/newsletter.php') ?>"
        >

            <input
                type="hidden"
                name="csrf"
                value="<?= csrf_token() ?>"
            >


            <input
                type="email"
                name="email"
                placeholder="Your email address"
                required
            >


            <button
                type="submit"
                class="btn primary"
            >
                Subscribe
            </button>

        </form>


    </div>

</section>


<?php

include __DIR__ . '/includes/footer.php';

?>