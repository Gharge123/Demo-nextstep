<?php
declare(strict_types=1);
session_start();
const DB_HOST='localhost'; const DB_NAME='nextstep'; const DB_USER='root'; const DB_PASS='';
const BASE_URL='/nextstep'; // Change to '' for domain root.
const SITE_URL='https://nextsteppune.com'; const SITE_NAME='Next Step';
const WHATSAPP='917972037331'; const PHONE='+91 79720 37331';
const SALES_EMAIL='sales@nextsteppune.com'; const SUPPORT_EMAIL='support@nextsteppune.com';
const ADMIN_EMAIL='admin@nextsteppune.com';
const GA4_ID=''; const GTM_ID='';
const CRM_WEBHOOK_URL=''; // Optional JSON webhook/Google Apps Script URL.
date_default_timezone_set('Asia/Kolkata');
function url(string $path=''):string{return rtrim(BASE_URL,'/').'/'.ltrim($path,'/');}
function e($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function redirect(string $path):never{header('Location: '.(preg_match('~^https?://~',$path)?$path:url($path)));exit;}
function flash(string $type,string $message):void{$_SESSION['flash']=['type'=>$type,'message'=>$message];}
function get_flash():?array{$f=$_SESSION['flash']??null;unset($_SESSION['flash']);return $f;}
function csrf_token():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function verify_csrf():void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Invalid CSRF token.');}}
function whatsapp_url(string $message='Hi Next Step, I would like to enquire about device rental.'):string{return 'https://wa.me/'.WHATSAPP.'?text='.rawurlencode($message);}
function slugify(string $text):string{$text=strtolower(trim($text));$text=preg_replace('/[^a-z0-9]+/','-',$text)??'';return trim($text,'-');}
function setting(string $key,string $default=''):string{static $cache=null;if($cache===null){$cache=[];try{foreach(db()->query('SELECT setting_key,setting_value FROM settings') as $r)$cache[$r['setting_key']]=$r['setting_value'];}catch(Throwable $e){}}return $cache[$key]??$default;}
function site_phone_link():string{return 'tel:+917972037331';}
function track_url(string $type,string $source='website'):string{return url('actions/track.php?type='.rawurlencode($type).'&source='.rawurlencode($source));}
function notify_email(string $to,string $subject,string $body):void{@mail($to,$subject,$body,"From: website@nextsteppune.com\r\nReply-To: ".SALES_EMAIL);}
