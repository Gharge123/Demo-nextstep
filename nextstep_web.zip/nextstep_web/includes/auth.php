<?php require_once __DIR__.'/functions.php';function require_admin():void{if(empty($_SESSION['admin_id'])){header('Location: '.url('admin/login.php'));exit;}}
