<?php
require_once __DIR__.'/../config/db.php';
function log_event(string $type,string $source='website'):void{try{$hash=hash('sha256',($_SERVER['REMOTE_ADDR']??'').'|nextstep');$s=db()->prepare('INSERT INTO leads_events(event_type,source,page_url,ip_hash,user_agent) VALUES(?,?,?,?,?)');$s->execute([$type,$source,substr($_SERVER['HTTP_REFERER']??'',0,500),$hash,substr($_SERVER['HTTP_USER_AGENT']??'',0,500)]);}catch(Throwable $e){}}
function post_webhook(array $payload):void{if(CRM_WEBHOOK_URL==='')return;$ch=curl_init(CRM_WEBHOOK_URL);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>5]);curl_exec($ch);curl_close($ch);}
function json_response(array $data,int $status=200):never{http_response_code($status);header('Content-Type: application/json');echo json_encode($data);exit;}

function client_logged_in():bool{return !empty($_SESSION['portal_user_id']);}
function require_client():void{if(!client_logged_in()){redirect('portal-login.php');}}
function client_user():?array{if(!client_logged_in())return null;static $u=null;if($u===null){$s=db()->prepare('SELECT * FROM portal_users WHERE id=? AND status="active"');$s->execute([$_SESSION['portal_user_id']]);$u=$s->fetch()?:null;}return $u;}
function client_asset(int $id):?array{$s=db()->prepare('SELECT a.* FROM assets a WHERE a.id=? AND a.portal_user_id=?');$s->execute([$id,$_SESSION['portal_user_id']??0]);return $s->fetch()?:null;}
function clean_slug(string $s):string{return trim(strtolower(preg_replace('/[^a-z0-9-]+/','-',str_replace(' ','-', $s))??''),'-');}
